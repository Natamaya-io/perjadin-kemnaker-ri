<script>
  import '../app.css';
  import { userStore, login, logout } from '$lib/stores/auth';
  import { page, navigating } from '$app/stores';
  import { fly } from 'svelte/transition';
  import { onMount } from 'svelte';
  import GlobalLoader from '$lib/components/ui/loader/GlobalLoader.svelte';

  $: activeRoute = $page.url?.pathname || '';
  
  let isLoading = true; // Start true for initial hydration
  let navLoading = false;
  let navTimer;

  // Handle navigation loading with debounce
  $: if ($navigating) {
      navTimer = setTimeout(() => {
          navLoading = true;
      }, 100); // 100ms delay before showing
  } else {
      clearTimeout(navTimer);
      navLoading = false;
  }

  // Handle initial hydration loading
  onMount(() => {
      // Simulate a brief "hard refresh" loading if needed, or just turn off immediately
      // A small delay feels more "app-like" on hard refresh
      setTimeout(() => {
          isLoading = false;
      }, 500);
  });

  $: showLoader = isLoading || navLoading;
</script>

{#if showLoader}
    <GlobalLoader />
{/if}

<div class="h-[100dvh] w-screen flex flex-col font-sans antialiased text-slate-900 overflow-hidden {activeRoute.startsWith('/login') ? 'bg-slate-900' : 'bg-slate-50'}">
  {#if $userStore.loggedIn}
  <!-- Desktop Header -->
  <header class="hidden md:block sticky top-0 z-50 w-full border-b border-slate-200 bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 shadow-sm transition-all flex-none print:hidden">
    <div class="container flex h-16 items-center max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="mr-8 flex items-center">
        <div class="flex items-center space-x-3 select-none">
          <img src="/kemnaker-ri.webp" alt="Logo" class="h-10 w-auto object-contain" />
          <div class="hidden sm:flex flex-col leading-none">
            <span class="font-serif font-bold text-lg text-slate-900 tracking-tight">Perjadin</span>
            <span class="font-sans text-xs italic text-slate-500 tracking-widest uppercase">Protokol</span>
          </div>
        </div>
      </div>
      
      <nav class="flex items-center space-x-1 text-sm font-medium flex-1">
        <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute === '/dashboard' ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard">Dashboard</a>
        {#if $userStore.role !== 'keuangan'}
        <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute.includes('/dashboard/pengajuan') ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard/pengajuan/new">Pengajuan</a>
        {/if}
        {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
            <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute.includes('/dashboard/admin/perdin') ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard/admin/perdin">Admin Keuangan</a>
        {/if}
        {#if $userStore.role === 'super_admin'}
            <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute.includes('/dashboard/admin/petugas') ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard/admin/petugas">Petugas</a>
            <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute.includes('/dashboard/admin/users') ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard/admin/users">User</a>
        {/if}
        {#if $userStore.role !== 'keuangan'}
        <a class="px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 {activeRoute.includes('/dashboard/laporan') ? 'text-primary bg-blue-50/50 font-semibold' : 'text-slate-600'}" href="/dashboard/laporan">Laporan</a>
        {/if}
      </nav>

      <div class="flex items-center space-x-4">
        <div class="flex items-center space-x-3 text-sm bg-slate-100/50 px-3 py-1.5 rounded-full border border-slate-200/60">
            <span class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Role</span>
            <span class="text-xs font-bold text-slate-800 uppercase">{$userStore.role}</span>
        </div>
        <button class="text-slate-400 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-red-50" title="Logout" on:click={logout}>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
        </button>
      </div>
    </div>
  </header>

  <!-- Mobile Top Bar -->
  <header class="md:hidden sticky top-0 z-50 w-full bg-white/90 backdrop-blur border-b border-slate-200 px-4 py-3 flex justify-between items-center shadow-sm flex-none print:hidden">
      <div class="flex items-center space-x-2">
          <img src="/kemnaker-ri.webp" alt="Logo" class="h-8 w-auto object-contain" />
          <div class="flex flex-col leading-none">
            <span class="font-serif font-bold text-base text-slate-900 tracking-tight">Perjadin</span>
            <span class="font-sans text-[10px] italic text-slate-500 tracking-widest uppercase">Protokol</span>
          </div>
      </div>
      <button class="text-slate-500" on:click={logout}>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
        </svg>
      </button>
  </header>
  {/if}

  <!-- Main Content Area (Scrollable) -->
  <main class="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar w-full relative">
    <div class="{$userStore.loggedIn ? 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 md:pb-8' : ''} min-h-full">
        {#key activeRoute}
            <div in:fly={{ y: 10, duration: 300, delay: 150 }} out:fly={{ y: -10, duration: 150 }} class="min-h-full">
                <slot />
            </div>
        {/key}
    </div>
  </main>

  {#if $userStore.loggedIn}
  <nav class="md:hidden sticky bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] flex-none print:hidden">
      <div class="grid {$userStore.role === 'super_admin' ? 'grid-cols-6' : ($userStore.role === 'keuangan' ? 'grid-cols-2' : 'grid-cols-3')} h-16">
          <a href="/dashboard" class="flex flex-col items-center justify-center space-y-1 {activeRoute === '/dashboard' ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              <span class="text-[10px] font-medium">Home</span>
          </a>
          {#if $userStore.role !== 'keuangan'}
          <a href="/dashboard/pengajuan/new" class="flex flex-col items-center justify-center space-y-1 {activeRoute.includes('/dashboard/pengajuan') ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
              </svg>
              <span class="text-[10px] font-medium">Pengajuan</span>
          </a>
          {/if}
          {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
          <a href="/dashboard/admin/perdin" class="flex flex-col items-center justify-center space-y-1 {activeRoute.includes('/dashboard/admin/perdin') ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 3.666A5.002 5.002 0 0112 21a5.002 5.002 0 01-3-9.666V5.5A2.5 2.5 0 0012 3a2.5 2.5 0 002.5 2.5V7z" />
              </svg>
              <span class="text-[10px] font-medium">Admin</span>
          </a>
          {/if}
          {#if $userStore.role === 'super_admin'}
            <a href="/dashboard/admin/petugas" class="flex flex-col items-center justify-center space-y-1 {activeRoute.includes('/dashboard/admin/petugas') ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                <span class="text-[10px] font-medium">Petugas</span>
            </a>
            <a href="/dashboard/admin/users" class="flex flex-col items-center justify-center space-y-1 {activeRoute.includes('/dashboard/admin/users') ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span class="text-[10px] font-medium">User</span>
            </a>
          {/if}
          {#if $userStore.role !== 'keuangan'}
          <a href="/dashboard/laporan" class="flex flex-col items-center justify-center space-y-1 {activeRoute.includes('/dashboard/laporan') ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'}">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span class="text-[10px] font-medium">Laporan</span>
          </a>
          {/if}
      </div>
  </nav>
  {/if}
</div>
