<script>
    import { recordsStore } from '$lib/stores/records';
    import { userStore } from '$lib/stores/auth';
    import { onMount } from 'svelte';
    import { cn } from '$lib/utils';
    import { fly } from 'svelte/transition';
    
    // UI
    import Table from '$lib/components/ui/table/Table.svelte';
    import TableHeader from '$lib/components/ui/table/TableHeader.svelte';
    import TableRow from '$lib/components/ui/table/TableRow.svelte';
    import TableHead from '$lib/components/ui/table/TableHead.svelte';
    import TableBody from '$lib/components/ui/table/TableBody.svelte';
    import TableCell from '$lib/components/ui/table/TableCell.svelte';
    import Button from '$lib/components/ui/button/Button.svelte';
    import Dialog from '$lib/components/ui/dialog/Dialog.svelte';
    import DialogHeader from '$lib/components/ui/dialog/DialogHeader.svelte';
    import DialogTitle from '$lib/components/ui/dialog/DialogTitle.svelte';
    import DialogFooter from '$lib/components/ui/dialog/DialogFooter.svelte';
    import Label from '$lib/components/ui/label/Label.svelte';
    import Input from '$lib/components/ui/input/Input.svelte';
    import Select from '$lib/components/ui/select/Select.svelte';
    import { ConfirmationModal } from '$lib/components/ui/confirmation-modal';
    import AlertModal from '$lib/components/ui/alert-modal/AlertModal.svelte';

    // Modal State
    let isModalOpen = false;
    let selectedRecord = null;
    let editingCosts = {
        ticketGo: 0,
        ticketBack: 0,
        dailyAllowanceDays: 0,
        dailyAllowanceRate: 0,
        hotelDays: 0,
        hotelRate: 0,
        localTransport: 0,
        regionalTransport: 0,
        transportMode: 'Pesawat'
    };

    // Alert State
    let isAlertOpen = false;
    let alertTitle = '';
    let alertDescription = '';

    function showAlert(title, description) {
        alertTitle = title;
        alertDescription = description;
        isAlertOpen = true;
    }

    // Filter & Sort State
    let searchQuery = '';
    let statusFilter = 'all'; // 'all', 'Submitted', 'Approved'
    let sortOption = 'date-desc'; // 'date-desc', 'date-asc', 'cost-desc', 'cost-asc'

    // Derived Records
    $: filteredRecords = $recordsStore
        .filter(r => {
            const query = searchQuery.toLowerCase();
            const matchSearch = 
                (r.employee?.name?.toLowerCase() || '').includes(query) ||
                (r.spd?.toLowerCase() || '').includes(query) ||
                (r.location?.toLowerCase() || '').includes(query);
            
            const matchStatus = statusFilter === 'all' || r.status === statusFilter;

            return matchSearch && matchStatus;
        })
        .sort((a, b) => {
            if (sortOption === 'date-desc') return new Date(b.startDate) - new Date(a.startDate);
            if (sortOption === 'date-asc') return new Date(a.startDate) - new Date(b.startDate);
            if (sortOption === 'cost-desc') return b.totalCost - a.totalCost;
            if (sortOption === 'cost-asc') return a.totalCost - b.totalCost;
            return 0;
        });

    // Derived Calculations
    $: totalDailyAllowance = editingCosts.dailyAllowanceDays * editingCosts.dailyAllowanceRate;
    $: totalHotel = editingCosts.hotelDays * editingCosts.hotelRate;
    $: totalTicket = Number(editingCosts.ticketGo) + Number(editingCosts.ticketBack);
    $: totalLocal = Number(editingCosts.localTransport);
    $: totalRegional = Number(editingCosts.regionalTransport);
    $: grandTotal = totalTicket + totalDailyAllowance + totalHotel + totalLocal + totalRegional;

    // Stats Calculations
    $: filteredTotalCost = filteredRecords.reduce((acc, r) => acc + (r.totalCost || 0), 0);
    $: filteredPendingCount = filteredRecords.filter(r => r.status === 'Submitted').length;

    let isConfirmOpen = false;

    function openEditModal(record) {
        selectedRecord = record;
        // Clone costs to avoid direct mutation before save
        editingCosts = { ...record.costs };
        isModalOpen = true;
    }

    function confirmSave() {
        if (editingCosts.localTransport > 500000) {
            showAlert('Peringatan', 'Transport Lokal maksimal Rp 500.000');
            return;
        }
        isConfirmOpen = true;
    }

    function processSave() {
        recordsStore.update(currentRecords => {
            return currentRecords.map(r => {
                if (r.spd === selectedRecord.spd) {
                    return {
                        ...r,
                        costs: { ...editingCosts },
                        totalCost: grandTotal,
                        status: 'Approved' // Auto approve on cost save? Or Keep Submitted. Let's say 'Processed'
                    };
                }
                return r;
            });
        });
        isModalOpen = false;
    }

    function formatCurrency(amount) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(amount);
    }

    function generateSPD(record) {
        window.open(`/print?type=spd&spd=${encodeURIComponent(record.spd)}`, '_blank');
    }

    function generateRincian(record) {
        window.open(`/print?type=rincian&spd=${encodeURIComponent(record.spd)}`, '_blank');
    }
</script>

<div class="space-y-6 pb-20">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-slate-900">Rekap & Kalkulasi</h2>
            <p class="text-slate-500">Kelola pengajuan dan hitung rincian biaya.</p>
        </div>
        <div class="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full md:w-auto">
             <div class="relative w-full md:w-64">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <Input type="text" placeholder="Cari Nama, SPD, Tujuan..." bind:value={searchQuery} class="pl-9 h-9 text-sm bg-white border-slate-200 w-full" />
             </div>
             
                          <div class="flex space-x-2 w-full sm:w-auto">
                              <div class="w-1/2 sm:w-32">
                                 <Select bind:value={statusFilter} class="h-9 text-xs w-full bg-white border-slate-200">
                                     <option value="all">Semua Status</option>
                                     <option value="Submitted">Submitted</option>
                                     <option value="Approved">Approved</option>
                                 </Select>
                              </div>
             
                              <div class="w-1/2 sm:w-40">
                                 <Select bind:value={sortOption} class="h-9 text-xs w-full bg-white border-slate-200">
                                     <option value="date-desc">Terbaru</option>
                                     <option value="date-asc">Terlama</option>
                                     <option value="cost-desc">Biaya Tertinggi</option>
                                     <option value="cost-asc">Biaya Terendah</option>
                                 </Select>
                              </div>
                          </div>
        </div>
    </div>

    {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Item</p>
                <p class="text-2xl font-bold text-slate-900">{filteredRecords.length}</p>
            </div>
            <div class="p-2 bg-slate-100 rounded-lg text-slate-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
            </div>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Anggaran</p>
                <p class="text-2xl font-bold text-emerald-600">{formatCurrency(filteredTotalCost)}</p>
            </div>
            <div class="p-2 bg-emerald-50 rounded-lg text-emerald-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-medium text-slate-500 uppercase tracking-wider">Perlu Proses</p>
                <p class="text-2xl font-bold text-amber-600">{filteredPendingCount}</p>
            </div>
            <div class="p-2 bg-amber-50 rounded-lg text-amber-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>
    </div>
    {/if}

    {#if $userStore.role !== 'super_admin' && $userStore.role !== 'keuangan'}
        <div class="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-slate-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <h3 class="text-lg font-medium text-slate-900">Akses Dibatasi</h3>
            <p class="text-slate-500 max-w-sm mt-1">Halaman ini khusus untuk Admin Keuangan. Silakan login dengan akun yang sesuai.</p>
        </div>
    {:else}
        <!-- Mobile Card View -->
        <div class="grid grid-cols-1 gap-4 md:hidden">
            {#each filteredRecords as record (record.id)}
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                    <div class="flex justify-between items-start">
                        <div>
                            <span class="text-xs font-mono text-slate-400 block mb-1">{record.spd}</span>
                            <h3 class="font-bold text-slate-800">{record.employee?.name || '-'}</h3>
                            <p class="text-xs text-slate-500">{record.employee?.rank || '-'} ({record.employee?.golongan || '-'})</p>
                        </div>
                        <span class={cn("px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide", 
                            record.status === 'Submitted' ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700")}>
                            {record.status}
                        </span>
                    </div>
                    
                    <div class="border-t border-b border-slate-50 py-3 space-y-2">
                        <div class="flex justify-between text-sm">
                            <span class="text-slate-500">Tujuan</span>
                            <span class="font-medium text-slate-700 text-right">{record.location}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-slate-500">Tanggal</span>
                            <span class="font-medium text-slate-700">{record.startDate}</span>
                        </div>
                        <div class="flex justify-between text-sm pt-2">
                            <span class="text-slate-500 font-semibold">Total Biaya</span>
                            <span class="font-bold text-blue-600">{formatCurrency(record.totalCost)}</span>
                        </div>
                    </div>

                    <div class="grid grid-cols-3 gap-2">
                        <Button variant="outline" size="sm" class="w-full text-xs h-9" on:click={() => openEditModal(record)}>Hitung</Button>
                        <Button variant="ghost" size="sm" class="w-full text-xs h-9 bg-slate-50 hover:bg-slate-100 text-slate-600" on:click={() => generateSPD(record)}>SPD</Button>
                        <Button variant="ghost" size="sm" class="w-full text-xs h-9 bg-slate-50 hover:bg-slate-100 text-slate-600" on:click={() => generateRincian(record)}>Rincian</Button>
                    </div>
                </div>
            {/each}
        </div>

        <!-- Desktop Table View -->
        <div class="hidden md:block rounded-xl border border-slate-200 shadow-sm bg-white overflow-hidden">
            <div class="overflow-x-auto w-full">
                <Table class="w-full text-sm text-left">
                    <TableHeader class="bg-slate-50 border-b border-slate-200">
                        <TableRow class="hover:bg-slate-50/50">
                            <TableHead class="w-[100px] min-w-[100px] font-semibold text-slate-700 pl-4 py-3">ID / SPD</TableHead>
                            <TableHead class="min-w-[200px] font-semibold text-slate-700 py-3">Pegawai</TableHead>
                            <TableHead class="min-w-[250px] font-semibold text-slate-700 py-3">Detail Perjalanan</TableHead>
                            <TableHead class="w-[120px] min-w-[120px] font-semibold text-slate-700 py-3">Status</TableHead>
                            <TableHead class="min-w-[160px] font-semibold text-slate-700 text-right py-3">Total Biaya</TableHead>
                            <TableHead class="w-[180px] min-w-[180px] font-semibold text-slate-700 text-right pr-4 py-3">Aksi</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {#each filteredRecords as record (record.id)}
                            <TableRow class="hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0">
                                <TableCell class="pl-4 py-3 align-top">
                                    <div class="flex flex-col gap-0.5">
                                        <span class="font-mono text-[10px] text-slate-400 leading-none">#{record.id}</span>
                                        <span class="font-medium text-xs text-slate-700">{record.spd}</span>
                                    </div>
                                </TableCell>
                                <TableCell class="py-3 align-top">
                                    <div class="flex flex-col gap-0.5">
                                        <span class="font-semibold text-slate-900 text-sm">{record.employee?.name || '-'}</span>
                                        <span class="text-xs text-slate-500">{record.employee?.rank || '-'}</span>
                                    </div>
                                </TableCell>
                                <TableCell class="py-3 align-top">
                                    <div class="flex flex-col gap-0.5 max-w-[250px]">
                                        <span class="font-medium text-slate-700 text-sm truncate" title="{record.location}, {record.province}">{record.location}, {record.province}</span>
                                        <span class="text-xs text-slate-500 flex items-center gap-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                            </svg>
                                            {record.startDate} s/d {record.endDate}
                                        </span>
                                    </div>
                                </TableCell>
                                <TableCell class="py-3 align-top">
                                    <span class={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide border", 
                                        record.status === 'Submitted' ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-emerald-50 text-emerald-700 border-emerald-200")}>
                                        {record.status}
                                    </span>
                                </TableCell>
                                <TableCell class="text-right font-mono font-medium text-slate-700 py-3 align-top">{formatCurrency(record.totalCost)}</TableCell>
                                <TableCell class="text-right pr-4 py-3 align-top">
                                    <div class="flex justify-end items-center gap-1">
                                        <Button variant="outline" size="sm" class="h-8 text-xs border-slate-200 bg-white hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm" on:click={() => openEditModal(record)}>Hitung</Button>
                                        <div class="h-4 w-px bg-slate-200 mx-1"></div>
                                        <div class="flex items-center gap-1">
                                            <button class="p-1.5 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-700 transition-colors" title="Cetak SPD" on:click={() => generateSPD(record)}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><line x1="10" x2="8" y1="9" y2="9"/></svg>
                                            </button>
                                            <button class="p-1.5 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-700 transition-colors" title="Cetak Rincian" on:click={() => generateRincian(record)}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/></svg>
                                            </button>
                                        </div>
                                    </div>
                                </TableCell>
                            </TableRow>
                        {/each}
                    </TableBody>
                </Table>
            </div>
        </div>
    {/if}

    <Dialog open={isModalOpen} on:close={() => isModalOpen = false}>
        <DialogHeader class="border-b border-slate-100 pb-4">
            <DialogTitle class="text-xl">Input Rincian Biaya</DialogTitle>
            <p class="text-sm text-slate-500">Lengkapi komponen biaya untuk <span class="font-semibold text-slate-800">{selectedRecord?.employee?.name}</span>.</p>
        </DialogHeader>
        
        <div class="grid gap-6 py-6 max-h-[60vh] overflow-y-auto pr-2">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-2">
                    <Label class="text-xs font-semibold uppercase text-slate-500 tracking-wider">Tiket Berangkat</Label>
                    <div class="relative">
                        <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                        <Input type="number" bind:value={editingCosts.ticketGo} class="pl-9 bg-slate-50 border-slate-200 focus:bg-white" />
                    </div>
                </div>
                <div class="space-y-2">
                    <Label class="text-xs font-semibold uppercase text-slate-500 tracking-wider">Tiket Pulang</Label>
                    <div class="relative">
                        <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                        <Input type="number" bind:value={editingCosts.ticketBack} class="pl-9 bg-slate-50 border-slate-200 focus:bg-white" />
                    </div>
                </div>
            </div>

            <div class="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-4">
                <h4 class="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Uang Harian
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="space-y-2 col-span-1">
                        <Label class="text-xs text-slate-500">Durasi (Hari)</Label>
                        <Input type="number" bind:value={editingCosts.dailyAllowanceDays} class="bg-white border-slate-200" />
                    </div>
                    <div class="space-y-2 col-span-1 sm:col-span-2">
                        <Label class="text-xs text-slate-500">Rate per Hari</Label>
                        <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                            <Input type="number" bind:value={editingCosts.dailyAllowanceRate} class="pl-9 bg-white border-slate-200" />
                        </div>
                    </div>
                </div>
                <div class="text-right text-sm font-mono font-medium text-slate-600 border-t border-slate-200 pt-2 mt-2">
                    Subtotal: {formatCurrency(editingCosts.dailyAllowanceDays * editingCosts.dailyAllowanceRate)}
                </div>
            </div>

            <div class="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-4">
                <h4 class="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                    Penginapan
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="space-y-2 col-span-1">
                        <Label class="text-xs text-slate-500">Durasi (Malam)</Label>
                        <Input type="number" bind:value={editingCosts.hotelDays} class="bg-white border-slate-200" />
                    </div>
                    <div class="space-y-2 col-span-1 sm:col-span-2">
                        <Label class="text-xs text-slate-500">Rate per Malam</Label>
                        <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                            <Input type="number" bind:value={editingCosts.hotelRate} class="pl-9 bg-white border-slate-200" />
                        </div>
                    </div>
                </div>
                <div class="text-right text-sm font-mono font-medium text-slate-600 border-t border-slate-200 pt-2 mt-2">
                    Subtotal: {formatCurrency(editingCosts.hotelDays * editingCosts.hotelRate)}
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div class="space-y-2">
                    <Label class="text-xs font-semibold uppercase text-slate-500 tracking-wider">Transport Lokal</Label>
                    <div class="relative">
                        <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                        <Input type="number" bind:value={editingCosts.localTransport} class="pl-9 bg-slate-50 border-slate-200 focus:bg-white" />
                    </div>
                    <p class="text-[10px] text-slate-400">Maks. Rp 500.000</p>
                </div>
                <div class="space-y-2">
                    <Label class="text-xs font-semibold uppercase text-slate-500 tracking-wider">Transport Daerah</Label>
                    <div class="relative">
                        <span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span>
                        <Input type="number" bind:value={editingCosts.regionalTransport} class="pl-9 bg-slate-50 border-slate-200 focus:bg-white" />
                    </div>
                </div>
            </div>

            <div class="space-y-2 pt-2">
                <Label class="text-xs font-semibold uppercase text-slate-500 tracking-wider">Mode Transportasi</Label>
                <Select bind:value={editingCosts.transportMode} class="bg-slate-50 border-slate-200">
                    <option value="Pesawat">Pesawat Udara</option>
                    <option value="Kendaraan Umum">Kendaraan Umum / Kereta</option>
                    <option value="Kendaraan Dinas">Kendaraan Dinas</option>
                </Select>
            </div>
        </div>

        <DialogFooter>
            <div class="w-full flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100 pt-4">
                <div class="w-full sm:w-auto flex justify-between sm:block text-left">
                    <span class="block text-xs text-slate-500 self-center sm:self-auto">Total Estimasi</span>
                    <span class="text-lg font-bold text-blue-600">{formatCurrency(grandTotal)}</span>
                </div>
                <div class="flex gap-2 w-full sm:w-auto">
                    <Button variant="outline" class="flex-1 sm:flex-none border-slate-200 text-slate-600" on:click={() => isModalOpen = false}>Batal</Button>
                    <Button class="flex-1 sm:flex-none bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20" on:click={confirmSave}>Simpan</Button>
                </div>
            </div>
        </DialogFooter>
    </Dialog>

    <ConfirmationModal
        bind:open={isConfirmOpen}
        title="Simpan Rincian Biaya"
        description="Apakah Anda yakin data rincian biaya ini sudah sesuai? Status akan diubah menjadi Approved."
        confirmText="Ya, Simpan & Approve"
        onConfirm={processSave}
    />
    
    <AlertModal
        bind:open={isAlertOpen}
        title={alertTitle}
        description={alertDescription}
    />
</div>
