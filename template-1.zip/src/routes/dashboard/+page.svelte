<script>
    import { recordsStore } from '$lib/stores/records';
    import { userStore } from '$lib/stores/auth';
    import Button from '$lib/components/ui/button/Button.svelte';

    // Helper for currency if not in utils
    function formatIDR(amount) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
    }

    $: records = $recordsStore;
    $: myRecords = ($userStore.role === 'super_admin' || $userStore.role === 'keuangan') ? records : records.filter(r => r.email === $userStore.email);

    // Stats
    $: totalTrips = records.length;
    $: totalCost = records.reduce((acc, r) => acc + (r.totalCost || 0), 0);
    $: activeTrips = records.filter(r => new Date(r.endDate) >= new Date()).length;
    $: pendingReports = myRecords.filter(r => r.status === 'Approved' && r.reportStatus !== 'Completed').length;

    // Recent
    $: recentRecords = [...myRecords].sort((a, b) => new Date(b.startDate) - new Date(a.startDate)).slice(0, 5);
</script>

<div class="space-y-8 pb-20">
    <!-- Welcome Section -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-8 text-white shadow-xl shadow-blue-900/20 relative overflow-hidden">
        <div class="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div class="absolute bottom-0 left-0 -mb-10 -ml-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
        
        <div class="relative z-10 space-y-2">
            <h1 class="text-3xl md:text-4xl font-bold tracking-tight">Halo, {$userStore.role === 'super_admin' ? 'Super Admin' : ($userStore.role === 'keuangan' ? 'Admin Keuangan' : 'Staf')}! 👋</h1>
            <p class="text-blue-100 text-lg max-w-xl">Selamat datang di Dashboard Perjalanan Dinas. Pantau aktivitas dan kelola laporan Anda dengan mudah.</p>
        </div>
        <div class="relative z-10 flex gap-3">
            {#if $userStore.role !== 'keuangan'}
            <a href="/dashboard/pengajuan/new">
                <Button class="bg-white text-blue-600 hover:bg-blue-50 border-0 shadow-lg font-semibold h-12 px-6">
                    + Pengajuan Baru
                </Button>
            </a>
            {/if}
            {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
                 <a href="/dashboard/admin/perdin">
                    <Button variant="outline" class="bg-blue-600/50 border-white/30 text-white hover:bg-blue-600/70 h-12 px-6">
                        Kelola Keuangan
                    </Button>
                </a>
            {/if}
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 bg-blue-50 text-blue-600 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                </div>
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Perjalanan</span>
            </div>
            <div class="text-3xl font-bold text-slate-900">{totalTrips}</div>
            <div class="text-sm text-slate-500 mt-1">Kegiatan tercatat</div>
        </div>

        {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 bg-emerald-50 text-emerald-600 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Anggaran</span>
            </div>
            <div class="text-3xl font-bold text-slate-900 tracking-tight">{formatIDR(totalCost)}</div>
            <div class="text-sm text-slate-500 mt-1">Realisasi biaya</div>
        </div>
        {/if}

        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 bg-amber-50 text-amber-600 rounded-xl group-hover:bg-amber-600 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Sedang Berjalan</span>
            </div>
            <div class="text-3xl font-bold text-slate-900">{activeTrips}</div>
            <div class="text-sm text-slate-500 mt-1">Kegiatan aktif</div>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 bg-purple-50 text-purple-600 rounded-xl group-hover:bg-purple-600 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Laporan Pending</span>
            </div>
            <div class="text-3xl font-bold text-slate-900">{pendingReports}</div>
            <div class="text-sm text-slate-500 mt-1">Belum dilaporkan</div>
        </div>
    </div>

    <!-- Recent Activity Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="font-bold text-slate-800 text-lg">Aktivitas Terbaru</h3>
            {#if $userStore.role === 'super_admin' || $userStore.role === 'keuangan'}
                <a href="/dashboard/admin/perdin" class="text-sm font-semibold text-blue-600 hover:text-blue-700">Lihat Semua &rarr;</a>
            {/if}
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-slate-50/80 text-slate-500 font-semibold uppercase text-xs tracking-wider">
                    <tr>
                        <th class="px-6 py-4">Pegawai</th>
                        <th class="px-6 py-4">Tujuan</th>
                        <th class="px-6 py-4">Tanggal</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4 text-right">Biaya</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    {#each recentRecords as record}
                        <tr class="hover:bg-slate-50/50 transition-colors">
                            <td class="px-6 py-4">
                                <div class="font-bold text-slate-800">{record.employee.name}</div>
                                <div class="text-xs text-slate-500">{record.spd}</div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="font-medium text-slate-700">{record.location}</div>
                                <div class="text-xs text-slate-500">{record.province}</div>
                            </td>
                            <td class="px-6 py-4 text-slate-600 whitespace-nowrap">
                                {new Date(record.startDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide
                                    {record.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}">
                                    {record.status}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-right font-medium text-slate-700">
                                {formatIDR(record.totalCost)}
                            </td>
                        </tr>
                    {/each}
                    {#if recentRecords.length === 0}
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-slate-500 italic">Belum ada aktivitas perjalanan dinas.</td>
                        </tr>
                    {/if}
                </tbody>
            </table>
        </div>
    </div>
</div>
