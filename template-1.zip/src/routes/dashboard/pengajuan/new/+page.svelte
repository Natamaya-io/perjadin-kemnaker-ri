<script>
    import { userStore } from '$lib/stores/auth';
    import { provincesStore, stakeholdersStore } from '$lib/stores/master-data';
    import { recordsStore, addRecord, employeesStore } from '$lib/stores/records';
    import { onMount } from 'svelte';
    import { goto } from '$app/navigation';
    import { fly } from 'svelte/transition';
    
    // UI Components
    import Input from '$lib/components/ui/input/Input.svelte';
    import Label from '$lib/components/ui/label/Label.svelte';
    import Select from '$lib/components/ui/select/Select.svelte';
    import Textarea from '$lib/components/ui/textarea/Textarea.svelte';
    import Checkbox from '$lib/components/ui/checkbox/Checkbox.svelte';
    import Button from '$lib/components/ui/button/Button.svelte';
    import { ConfirmationModal } from '$lib/components/ui/confirmation-modal';

    // Form State
    let formData = {
        startDate: '',
        endDate: '',
        location: '',
        province: '',
        purpose: 'persiapan', // Default
        stakeholder: '',
        agenda: '',
        selectedEmployees: []
    };

    let isConfirmOpen = false;

    function toggleEmployee(employeeId) {
        if (formData.selectedEmployees.includes(employeeId)) {
            formData.selectedEmployees = formData.selectedEmployees.filter(id => id !== employeeId);
        } else {
            formData.selectedEmployees = [...formData.selectedEmployees, employeeId];
        }
    }

    function generateId() {
        const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `PERDIN-${date}-${random}`;
    }
    
    function handleSubmit() {
        if (formData.selectedEmployees.length > 6) {
            alert('Maksimal 6 Petugas Protokol yang diperbolehkan dalam satu pengajuan.');
            return;
        }

        if (!formData.startDate || !formData.endDate || !formData.province || formData.selectedEmployees.length === 0) {
            alert('Harap lengkapi semua field wajib dan pilih minimal satu pegawai.');
            return;
        }

        isConfirmOpen = true;
    }

    function processSubmit() {
        const tripData = {
            id: generateId(),
            email: $userStore.email,
            startDate: formData.startDate,
            endDate: formData.endDate,
            location: formData.location,
            province: formData.province,
            purpose: formData.purpose === 'persiapan' ? 'Persiapan dan Pendampingan Kunjungan Kerja' : 'Koordinasi dan Konsultasi Kunjungan Kerja',
            stakeholder: formData.stakeholder,
            agenda: formData.agenda,
            employees: $employeesStore.filter(e => formData.selectedEmployees.includes(e.id))
        };
        
        addRecord(tripData);

        // alert('Pengajuan Berhasil Disimpan!'); // Moved to modal flow implicit success
        if ($userStore.role === 'super_admin' || $userStore.role === 'keuangan') {
            goto('/dashboard/admin/perdin');
        } else {
            goto('/dashboard');
        }
    }
</script>

<div class="max-w-4xl mx-auto space-y-8 pb-20">
    <div class="space-y-2">
        <h1 class="text-3xl font-bold text-slate-900 tracking-tight">Pengajuan Baru</h1>
        <p class="text-slate-500">Buat draf perjalanan dinas dan protokol baru.</p>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Form Section -->
        <div class="lg:col-span-2 space-y-6">
            
            <!-- Card: Informasi Dasar -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                    <h3 class="font-semibold text-slate-800 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Informasi Dasar
                    </h3>
                </div>
                <div class="p-6 space-y-6">
                    <div class="space-y-2">
                        <Label class="text-slate-600">Email Pengaju</Label>
                        <Input value={$userStore.email} readonly disabled class="bg-slate-50 text-slate-500 border-slate-200" />
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <Label class="text-slate-600">Tanggal Mulai <span class="text-red-500">*</span></Label>
                            <Input type="date" bind:value={formData.startDate} required class="h-11" />
                        </div>
                        <div class="space-y-2">
                            <Label class="text-slate-600">Tanggal Selesai <span class="text-red-500">*</span></Label>
                            <Input type="date" bind:value={formData.endDate} required class="h-11" />
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card: Lokasi & Tujuan -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                    <h3 class="font-semibold text-slate-800 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        Lokasi & Tujuan
                    </h3>
                </div>
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <Label class="text-slate-600">Lokasi Dinas (Kab/Kota)</Label>
                            <Input placeholder="Contoh: Surabaya" bind:value={formData.location} class="h-11" />
                        </div>
                        <div class="space-y-2">
                            <Label class="text-slate-600">Provinsi <span class="text-red-500">*</span></Label>
                            <Select bind:value={formData.province} class="h-11">
                                <option value="" disabled selected>Pilih Provinsi</option>
                                {#each $provincesStore as province}
                                    <option value={province}>{province}</option>
                                {/each}
                            </Select>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <Label class="text-slate-600">Tujuan Perjalanan</Label>
                        <div class="grid grid-cols-1 gap-3">
                            <label class="relative flex items-center p-4 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors has-[:checked]:border-blue-500 has-[:checked]:bg-blue-50/30">
                                <input type="radio" name="purpose" value="persiapan" bind:group={formData.purpose} class="accent-blue-600 h-4 w-4 mr-3" />
                                <span class="text-sm font-medium text-slate-700">Persiapan dan Pendampingan Kunjungan Kerja</span>
                            </label>
                            <label class="relative flex items-center p-4 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors has-[:checked]:border-blue-500 has-[:checked]:bg-blue-50/30">
                                <input type="radio" name="purpose" value="koordinasi" bind:group={formData.purpose} class="accent-blue-600 h-4 w-4 mr-3" />
                                <span class="text-sm font-medium text-slate-700">Koordinasi dan Konsultasi Kunjungan Kerja</span>
                            </label>
                        </div>
                    </div>

                    <div class="space-y-2">
                        <Label class="text-slate-600">Detail Agenda</Label>
                        <Textarea placeholder="Jelaskan detail agenda kegiatan secara singkat..." bind:value={formData.agenda} class="min-h-[100px] resize-y" />
                    </div>
                </div>
            </div>

        </div>

        <!-- Sidebar Section -->
        <div class="lg:col-span-1 space-y-6">
            
            <!-- Card: Stakeholder -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                    <h3 class="font-semibold text-slate-800">Stakeholder Terkait</h3>
                </div>
                <div class="p-6 space-y-3">
                    {#each $stakeholdersStore as sh, i}
                        <label class="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer">
                            <input type="radio" name="stakeholder" value={sh} bind:group={formData.stakeholder} class="mt-1 accent-blue-600 h-4 w-4 shrink-0" />
                            <span class="text-sm text-slate-600 leading-snug">{sh}</span>
                        </label>
                    {/each}
                </div>
            </div>

            <!-- Card: Pegawai -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[500px]">
                <div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h3 class="font-semibold text-slate-800">Pilih Petugas</h3>
                    <span class="text-xs font-medium px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                        {formData.selectedEmployees.length}/6
                    </span>
                </div>
                <div class="p-4 overflow-y-auto flex-1 space-y-2">
                    {#each $employeesStore as employee}
                        <label class="flex items-center space-x-3 p-3 rounded-lg border border-transparent hover:border-slate-200 hover:bg-slate-50 transition-all cursor-pointer has-[:checked]:bg-blue-50/30 has-[:checked]:border-blue-200">
                            <input type="checkbox" 
                                checked={formData.selectedEmployees.includes(employee.id)}
                                on:change={() => toggleEmployee(employee.id)}
                                class="accent-blue-600 h-5 w-5 rounded border-slate-300 shrink-0"
                            />
                            <div class="grid gap-0.5">
                                <span class="text-sm font-semibold text-slate-800">{employee.name}</span>
                                <span class="text-xs text-slate-500">{employee.rank} - {employee.golongan}</span>
                            </div>
                        </label>
                    {/each}
                </div>
                <div class="p-4 border-t border-slate-100 bg-slate-50/50">
                    <p class="text-xs text-slate-500 text-center mb-3">Pastikan data sudah benar sebelum menyimpan.</p>
                    <Button class="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20" on:click={handleSubmit}>
                        Simpan Pengajuan
                    </Button>
                </div>
            </div>

        </div>
    </div>

    <ConfirmationModal 
        bind:open={isConfirmOpen}
        title="Simpan Pengajuan"
        description="Apakah Anda yakin data pengajuan ini sudah benar? Setelah disimpan, data akan masuk ke sistem."
        confirmText="Ya, Simpan"
        onConfirm={processSubmit}
    />
</div>
