<script>
    import { login, authenticate } from '$lib/stores/auth';
    import { goto } from '$app/navigation';
    import Button from '$lib/components/ui/button/Button.svelte';
    import Input from '$lib/components/ui/input/Input.svelte';
    import Label from '$lib/components/ui/label/Label.svelte';
    import { fly, fade } from 'svelte/transition';

    let email = '';
    let password = '';
    let isLoading = false;
    let errorMessage = '';
    let showPassword = false;

    async function handleLogin() {
        errorMessage = '';
        if (!email || !password) {
            errorMessage = 'Email dan Password tidak boleh kosong';
            return;
        }

        isLoading = true;
        // Simulate network delay
        await new Promise(r => setTimeout(r, 800));
        
        const result = authenticate(email, password);
        
        if (result.success) {
            const user = result.user;
            // Success
            login(email, user.role);
            goto('/dashboard');
        } else {
            errorMessage = 'Email atau password salah.';
            isLoading = false;
        }
    }
</script>

<!-- Root Container: Uses 100dvh for perfect mobile height and allows scrolling -->
<div class="relative min-h-[100dvh] w-full flex flex-col items-center justify-center p-4 sm:p-6 overflow-x-hidden">
    
    <!-- Fixed Background Layer: Stays compliant during scroll -->
    <div class="fixed inset-0 z-0 bg-slate-900 pointer-events-none">
        <!-- Gradient Mesh -->
        <div class="absolute inset-0 bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#1e293b]"></div>
        
        <!-- Ambient Orbs -->
        <div class="absolute top-[-10%] left-[-10%] w-[60vw] h-[60vw] bg-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div class="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] bg-indigo-600/20 rounded-full blur-[120px] animate-pulse" style="animation-delay: 2s;"></div>
        
        <!-- Grid Pattern Overlay (Optional Texture) -->
        <div class="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))] opacity-10"></div>
    </div>

    <!-- Back Button -->
    <a href="/" class="fixed top-6 left-6 z-20 p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all backdrop-blur-md border border-white/5" title="Kembali ke Beranda" in:fade={{ duration: 300 }}>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
    </a>

    <!-- Main Content Wrapper: Z-Index above background -->
    <div class="relative z-10 w-full max-w-[400px] flex flex-col my-auto" in:fly={{ y: 20, duration: 600, delay: 100 }}>
        
        <!-- Login Card -->
        <div class="bg-white/95 backdrop-blur-2xl border border-white/20 rounded-3xl shadow-2xl shadow-black/20 overflow-hidden ring-1 ring-white/40">
            
            <!-- Header -->
            <div class="relative px-8 pt-10 pb-6 text-center bg-gradient-to-b from-white via-white to-slate-50/80 border-b border-slate-100/80">
                 <img src="/kemnaker-ri.webp" alt="Logo Kemnaker RI" class="mx-auto h-20 w-auto object-contain mb-5" />
                <div class="space-y-1">
                    <h1 class="text-2xl font-serif font-bold tracking-tight text-slate-900">Perjadin Protokol</h1>
                    <p class="text-xs font-medium text-slate-500 uppercase tracking-widest">Kementerian Ketenagakerjaan RI</p>
                </div>
            </div>
            
            <!-- Body -->
            <div class="p-6 sm:p-8 space-y-6 bg-white">
                
                <!-- Demo Banner -->
                <div class="bg-blue-50/60 border border-blue-100/60 rounded-xl p-3.5 flex flex-col gap-1.5">
                    <div class="flex items-center gap-2 text-xs font-bold text-blue-800">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                        </svg>
                        Akun Demo (Password: 123456)
                    </div>
                    <div class="text-[10px] text-blue-700/80 font-mono pl-5 grid grid-cols-1 gap-0.5">
                        <div class="flex justify-between"><span>Staf:</span> <span class="select-all cursor-pointer hover:text-blue-900">user@kemnaker.go.id</span></div>
                        <div class="flex justify-between"><span>Super Admin:</span> <span class="select-all cursor-pointer hover:text-blue-900">admin@kemnaker.go.id</span></div>
                        <div class="flex justify-between"><span>Keuangan:</span> <span class="select-all cursor-pointer hover:text-blue-900">keuangan@kemnaker.go.id</span></div>
                        <div class="flex justify-between"><span>PPK:</span> <span class="select-all cursor-pointer hover:text-blue-900">ppk@kemnaker.go.id</span></div>
                    </div>
                </div>

                <!-- Error Message -->
                {#if errorMessage}
                    <div class="text-xs font-medium text-red-600 bg-red-50 p-3 rounded-lg border border-red-100 text-center animate-shake">
                        {errorMessage}
                    </div>
                {/if}

                <!-- Form -->
                <form class="space-y-5" on:submit|preventDefault={handleLogin}>
                    <div class="space-y-1.5 group">
                        <Label class="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1 group-focus-within:text-blue-600 transition-colors">Email Kedinasan</Label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
                                </svg>
                            </div>
                            <Input 
                                type="email" 
                                bind:value={email} 
                                placeholder="nama@kemnaker.go.id" 
                                class="pl-11 h-12 text-sm bg-slate-50 border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all rounded-xl shadow-sm placeholder:text-slate-300" 
                            />
                        </div>
                    </div>
                    
                    <div class="space-y-1.5 group">
                        <Label class="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1 group-focus-within:text-blue-600 transition-colors">Password</Label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                            </div>
                            <Input 
                                type={showPassword ? 'text' : 'password'} 
                                bind:value={password} 
                                placeholder="••••••••" 
                                class="pl-11 pr-11 h-12 text-sm bg-slate-50 border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all rounded-xl shadow-sm placeholder:text-slate-300" 
                            />
                            <button 
                                type="button"
                                class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none transition-colors"
                                on:click={() => showPassword = !showPassword}
                                tabindex="-1"
                            >
                                {#if showPassword}
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                                    </svg>
                                {:else}
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                    </svg>
                                {/if}
                            </button>
                        </div>
                    </div>

                    <Button type="submit" class="w-full h-12 text-sm font-bold text-white shadow-lg shadow-blue-500/30 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all transform active:scale-[0.98] rounded-xl" disabled={isLoading}>
                        {#if isLoading}
                            <div class="flex items-center justify-center gap-2">
                                <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                <span>Memproses...</span>
                            </div>
                        {:else}
                            Masuk Dashboard
                        {/if}
                    </Button>
                </form>
            </div>
            
            <!-- Footer -->
            <div class="px-8 py-4 bg-slate-50 border-t border-slate-100 flex justify-center">
                <p class="text-[10px] text-slate-400 font-medium tracking-wide">
                    Sistem Informasi Terintegrasi &copy; {new Date().getFullYear()}
                </p>
            </div>
        </div>
        
        <!-- Bottom Link (Optional) -->
        <div class="mt-8 text-center">
            <a href="/" class="text-xs text-white/40 hover:text-white/80 transition-colors font-medium">Hubungi admin untuk bantuan teknis</a>
        </div>
    </div>
</div>

<style>
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-4px); }
        75% { transform: translateX(4px); }
    }
    .animate-shake {
        animation: shake 0.3s ease-in-out;
    }
</style>