import { writable } from 'svelte/store';
import { browser } from '$app/environment';

const LOCATIONS = [
    { city: "Surabaya", prov: "Jawa Timur" },
    { city: "Bandung", prov: "Jawa Barat" },
    { city: "Semarang", prov: "Jawa Tengah" },
    { city: "Yogyakarta", prov: "DI Yogyakarta" },
    { city: "Medan", prov: "Sumatera Utara" },
    { city: "Makassar", prov: "Sulawesi Selatan" },
    { city: "Denpasar", prov: "Bali" },
    { city: "Balikpapan", prov: "Kalimantan Timur" },
    { city: "Banjarmasin", prov: "Kalimantan Selatan" },
    { city: "Palembang", prov: "Sumatera Selatan" },
    { city: "Padang", prov: "Sumatera Barat" },
    { city: "Manado", prov: "Sulawesi Utara" },
    { city: "Ambon", prov: "Maluku" },
    { city: "Jayapura", prov: "Papua" },
    { city: "Mataram", prov: "Nusa Tenggara Barat" }
];

const PURPOSES = [
    "Persiapan dan Pendampingan Kunjungan Kerja",
    "Koordinasi dan Konsultasi Kunjungan Kerja",
    "Monitoring dan Evaluasi Program",
    "Bimbingan Teknis Ketenagakerjaan",
    "Rapat Koordinasi Nasional"
];

// Default Employees Data
const DEFAULT_EMPLOYEES = [
    { id: 1, name: "Budi Santoso", nip: "198501012010011001", rank: "Penata", golongan: "III/c" },
    { id: 2, name: "Siti Aminah", nip: "199002022015022002", rank: "Penata Muda", golongan: "III/a" },
    { id: 3, name: "Ahmad Fauzi", nip: "198003032005031003", rank: "Pembina", golongan: "IV/a" },
    { id: 4, name: "Dewi Ratna", nip: "199504042020042004", rank: "Pengatur", golongan: "II/c" },
    { id: 5, name: "Eko Prasetyo", nip: "198805052012051005", rank: "Penata Tingkat I", golongan: "III/d" },
    { id: 6, name: "Rina Wati", nip: "199206062016062006", rank: "Penata Muda Tk. I", golongan: "III/b" },
    { id: 7, name: "Joko Widodo", nip: "197807072002071007", rank: "Pembina Utama Muda", golongan: "IV/c" },
    { id: 8, name: "Megawati", nip: "198308082008082008", rank: "Pembina Tk. I", golongan: "IV/b" },
    { id: 9, name: "Susilo Bambang", nip: "197509091999091009", rank: "Pembina Utama Madya", golongan: "IV/d" },
    { id: 10, name: "Ani Yudhoyono", nip: "198610102011102010", rank: "Penata", golongan: "III/c" },
    { id: 20, name: "Anies Baswedan", nip: "198008202005081020", rank: "Pembina", golongan: "IV/a" }
];

// --- Employees Store Logic ---
export const employeesStore = writable(DEFAULT_EMPLOYEES);

if (browser) {
    try {
        const storedEmployees = localStorage.getItem('perjadin_employees');
        if (storedEmployees) {
            employeesStore.set(JSON.parse(storedEmployees));
        }
    } catch (e) {
        console.error("Failed to load employees from localStorage", e);
    }

    employeesStore.subscribe(val => {
        try {
            localStorage.setItem('perjadin_employees', JSON.stringify(val));
        } catch (e) {
            console.error("Failed to save employees to localStorage", e);
        }
    });
}

export function addEmployee(employeeData) {
    employeesStore.update(employees => {
        const newId = employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1;
        return [...employees, { ...employeeData, id: newId }];
    });
}

export function updateEmployee(id, updatedData) {
    employeesStore.update(employees => {
        return employees.map(emp => emp.id === id ? { ...emp, ...updatedData } : emp);
    });
}

export function removeEmployee(id) {
    employeesStore.update(employees => employees.filter(emp => emp.id !== id));
}


// --- Records Store Logic ---

function generateRecords(count, employees) {
    const records = [];
    const now = new Date();

    for (let i = 0; i < count; i++) {
        const isPast = Math.random() > 0.3; // 70% past records
        const dateOffset = isPast ? -Math.floor(Math.random() * 300) : Math.floor(Math.random() * 60);
        const startDate = new Date(now);
        startDate.setDate(now.getDate() + dateOffset);
        
        const duration = Math.floor(Math.random() * 4) + 2; // 2-5 days
        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + duration - 1);

        const loc = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
        // Use provided employees list or fallback to default if empty
        const empList = employees.length > 0 ? employees : DEFAULT_EMPLOYEES;
        const emp = empList[Math.floor(Math.random() * empList.length)];
        const purpose = PURPOSES[Math.floor(Math.random() * PURPOSES.length)];
        
        // Status logic
        let status = 'Submitted';
        let reportStatus = 'Pending';
        let reportData = null;
        let costs = {
             ticketGo: 0,
             ticketBack: 0,
             dailyAllowanceDays: 0,
             dailyAllowanceRate: 0,
             hotelDays: 0,
             hotelRate: 0,
             localTransport: 0,
             regionalTransport: 0,
             transportMode: "Pesawat"
        };
        let totalCost = 0;

        if (isPast) {
            status = Math.random() > 0.1 ? 'Approved' : 'Submitted'; // Most past are approved
            if (status === 'Approved') {
                // Generate costs
                costs = {
                    ticketGo: Math.floor(Math.random() * 2000000) + 1000000,
                    ticketBack: Math.floor(Math.random() * 2000000) + 1000000,
                    dailyAllowanceDays: duration,
                    dailyAllowanceRate: 530000, // Standard rate
                    hotelDays: duration - 1,
                    hotelRate: Math.floor(Math.random() * 800000) + 400000,
                    localTransport: Math.floor(Math.random() * 300000) + 100000,
                    regionalTransport: 0,
                    transportMode: "Pesawat"
                };
                totalCost = costs.ticketGo + costs.ticketBack + (costs.dailyAllowanceDays * costs.dailyAllowanceRate) + (costs.hotelDays * costs.hotelRate) + costs.localTransport;

                // Report logic
                if (Math.random() > 0.4) {
                    reportStatus = 'Completed';
                    reportData = {
                        text: `Kegiatan ${purpose} di ${loc.city} berjalan dengan lancar. Telah dilakukan koordinasi dengan pihak terkait dan disepakati beberapa poin penting untuk tindak lanjut.`,
                        submittedAt: endDate.toISOString(),
                        files: [] // Mock empty files
                    };
                }
            }
        }

        const spdNumber = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        const month = startDate.getMonth() + 1;
        const romanMonth = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"][month - 1];
        const spd = `SPD-${spdNumber}/${romanMonth}/${startDate.getFullYear()}`;

        records.push({
            id: `PERDIN-${startDate.toISOString().slice(0,10).replace(/-/g,'')}-${Math.floor(Math.random()*1000)}`,
            spd: spd,
            employee: emp,
            email: "user@kemnaker.go.id", // Assign to demo user for visibility
            startDate: startDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0],
            location: loc.city,
            province: loc.prov,
            purpose: purpose,
            stakeholder: "Menteri Ketenagakerjaan",
            agenda: `Melakukan ${purpose.toLowerCase()} bersama tim protokol dan pemda setempat.`,
            status: status,
            totalCost: totalCost,
            costs: costs,
            reportStatus: reportStatus,
            reportData: reportData
        });
    }
    
    // Sort by date descending
    return records.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
}

const initialData = generateRecords(50, DEFAULT_EMPLOYEES); 

export const recordsStore = writable(initialData);

if (browser) {
    try {
        const stored = localStorage.getItem('perjadin_records');
        if (stored) {
            const parsed = JSON.parse(stored);
            
            // Fix missing reportStatus and duplicate IDs
            const seenIds = new Set();
            const migrated = parsed.map((r, index) => {
                let newId = r.id;
                // If ID is duplicate or strictly equal to another one seen so far
                if (seenIds.has(newId)) {
                    newId = `${r.id}-${index}`; 
                }
                seenIds.add(newId);
                
                return {
                    ...r,
                    id: newId,
                    reportStatus: r.reportStatus || 'Pending',
                    reportData: r.reportData || null
                };
            });

            if (parsed.length < 5) {
                 recordsStore.set(initialData);
            } else {
                 recordsStore.set(migrated);
            }
        } else {
             recordsStore.set(initialData);
        }
    } catch (e) {
        console.error("Failed to load records from localStorage", e);
    }

    let saveTimer;
    recordsStore.subscribe(val => {
        try {
            if (saveTimer) clearTimeout(saveTimer);
            saveTimer = setTimeout(() => {
                localStorage.setItem('perjadin_records', JSON.stringify(val));
            }, 500);
        } catch (e) {
            console.error("Failed to save records to localStorage", e);
        }
    });
}

export function addRecord(tripData) {
    recordsStore.update(records => {
        const newRecords = tripData.employees.map((emp, index) => {
             const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
             const spd = `SPD-${random}-${index}/XII/2026`;
             
             return {
                 id: `${tripData.id}-${index}`,
                 spd: spd,
                 employee: emp,
                 email: tripData.email,
                 startDate: tripData.startDate,
                 endDate: tripData.endDate,
                 location: tripData.location,
                 province: tripData.province,
                 purpose: tripData.purpose,
                 stakeholder: tripData.stakeholder,
                 agenda: tripData.agenda,
                 status: 'Submitted',
                 totalCost: 0,
                 costs: {
                    ticketGo: 0,
                    ticketBack: 0,
                    dailyAllowanceDays: 0,
                    dailyAllowanceRate: 0,
                    hotelDays: 0,
                    hotelRate: 0,
                    localTransport: 0,
                    regionalTransport: 0,
                    transportMode: 'Pesawat'
                },
                reportStatus: 'Pending',
                reportData: null
             };
        });
        return [...newRecords, ...records]; // Prepend new
    });
}
