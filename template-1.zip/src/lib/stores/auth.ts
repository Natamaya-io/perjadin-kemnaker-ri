import { writable, get } from 'svelte/store';
import { browser } from '$app/environment';

// --- Session Management ---
const storedUser = browser ? localStorage.getItem('user_session') : null;
const initialUser = storedUser ? JSON.parse(storedUser) : {
    email: null,
    role: null,
    loggedIn: false
};

// Migrate old 'admin' role to 'super_admin'
if (initialUser.role === 'admin') {
    initialUser.role = 'super_admin';
}

export const userStore = writable(initialUser);

if (browser) {
    userStore.subscribe(value => {
        if (value.loggedIn) {
            localStorage.setItem('user_session', JSON.stringify(value));
        } else {
            localStorage.removeItem('user_session');
        }
    });
}

export const login = (email, role) => {
    userStore.set({ email, role, loggedIn: true });
};

export const logout = () => {
    userStore.set({ email: null, role: null, loggedIn: false });
};


// --- User Database Management ---
const DEFAULT_USERS = [
    { id: 1, email: 'user@kemnaker.go.id', password: '123456', role: 'user', name: 'Staf Pengaju' },
    { id: 2, email: 'admin@kemnaker.go.id', password: '123456', role: 'super_admin', name: 'Super Admin' },
    { id: 3, email: 'ppk@kemnaker.go.id', password: '123456', role: 'ppk', name: 'Pejabat Pembuat Komitmen' },
    { id: 4, email: 'keuangan@kemnaker.go.id', password: '123456', role: 'keuangan', name: 'Admin Keuangan' }
];

export const usersStore = writable(DEFAULT_USERS);

if (browser) {
    try {
        const storedUsers = localStorage.getItem('app_users');
        if (storedUsers) {
            let parsedUsers = JSON.parse(storedUsers);
            // Migrate old 'admin' role to 'super_admin'
            parsedUsers = parsedUsers.map((u: any) => u.role === 'admin' ? { ...u, role: 'super_admin' } : u);
            usersStore.set(parsedUsers);
        } else {
            // Persist defaults so we always have the demo accounts
            usersStore.set(DEFAULT_USERS);
        }
    } catch (e) {
        console.error("Failed to load users", e);
    }

    usersStore.subscribe(val => {
         try {
            localStorage.setItem('app_users', JSON.stringify(val));
        } catch (e) {
            console.error("Failed to save users", e);
        }
    });
}

export function addUser(user) {
    usersStore.update(users => {
        const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
        return [...users, { ...user, id: newId }];
    });
}

export function updateUser(id, updatedData) {
    usersStore.update(users => users.map(u => u.id === id ? { ...u, ...updatedData } : u));
}

export function removeUser(id) {
    usersStore.update(users => users.filter(u => u.id !== id));
}

export function authenticate(email, password) {
    const users = get(usersStore);
    const user = users.find(u => u.email === email && u.password === password);
    return user ? { success: true, user } : { success: false };
}
