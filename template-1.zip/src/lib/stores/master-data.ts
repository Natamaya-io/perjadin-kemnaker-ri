import { writable } from 'svelte/store';

export const PROVINCES = [
    "Aceh", "Sumatera Utara", "Sumatera Barat", "Riau", "Jambi", "Sumatera Selatan", "Bengkulu", "Lampung", "Kepulauan Bangka Belitung", "Kepulauan Riau",
    "DKI Jakarta", "Jawa Barat", "Jawa Tengah", "DI Yogyakarta", "Jawa Timur", "Banten",
    "Bali", "Nusa Tenggara Barat", "Nusa Tenggara Timur",
    "Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan", "Kalimantan Timur", "Kalimantan Utara",
    "Sulawesi Utara", "Sulawesi Tengah", "Sulawesi Selatan", "Sulawesi Tenggara", "Gorontalo", "Sulawesi Barat",
    "Maluku", "Maluku Utara",
    "Papua", "Papua Barat", "Papua Selatan", "Papua Tengah", "Papua Pegunungan", "Papua Barat Daya"
];

export const STAKEHOLDERS = [
    "Menteri Ketenagakerjaan",
    "Wakil Menteri Ketenagakerjaan",
    "Pendamping Menteri Ketenagakerjaan",
    "Pendamping Wakil Menteri Ketenagakerjaan"
];

export const provincesStore = writable(PROVINCES);
export const stakeholdersStore = writable(STAKEHOLDERS);
