import { i as sanitize_props, r as rest_props, j as fallback, k as attributes, f as clsx, l as bind_props } from "./index2.js";
import { c as cn } from "./Button.js";
function Input($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["class", "value"]);
  $$renderer.component(($$renderer2) => {
    let classes;
    let className = fallback($$props["class"], void 0);
    let value = fallback($$props["value"], "");
    classes = cn("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className);
    $$renderer2.push(`<input${attributes({ value, class: clsx(classes), ...$$restProps }, void 0, void 0, void 0, 4)}/>`);
    bind_props($$props, { class: className, value });
  });
}
export {
  Input as I
};
