import { w as writable } from "./index.js";
const LOCATIONS = [
  { city: "Surabaya", prov: "Jawa Timur" },
  { city: "Bandung", prov: "Jawa Barat" },
  { city: "Semarang", prov: "Jawa Tengah" },
  { city: "Yogyakarta", prov: "DI Yogyakarta" },
  { city: "Medan", prov: "Sumatera Utara" },
  { city: "Makassar", prov: "Sulawesi Selatan" },
  { city: "Denpasar", prov: "Bali" },
  { city: "Balikpapan", prov: "Kalimantan Timur" },
  { city: "Banjarmasin", prov: "Kalimantan Selatan" },
  { city: "Palembang", prov: "Sumatera Selatan" },
  { city: "Padang", prov: "Sumatera Barat" },
  { city: "Manado", prov: "Sulawesi Utara" },
  { city: "Ambon", prov: "Maluku" },
  { city: "Jayapura", prov: "Papua" },
  { city: "Mataram", prov: "Nusa Tenggara Barat" }
];
const PURPOSES = [
  "Persiapan dan Pendampingan Kunjungan Kerja",
  "Koordinasi dan Konsultasi Kunjungan Kerja",
  "Monitoring dan Evaluasi Program",
  "Bimbingan Teknis Ketenagakerjaan",
  "Rapat Koordinasi Nasional"
];
const DEFAULT_EMPLOYEES = [
  { id: 1, name: "Budi Santoso", nip: "198501012010011001", rank: "Penata", golongan: "III/c" },
  { id: 2, name: "Siti Aminah", nip: "199002022015022002", rank: "Penata Muda", golongan: "III/a" },
  { id: 3, name: "Ahmad Fauzi", nip: "198003032005031003", rank: "Pembina", golongan: "IV/a" },
  { id: 4, name: "Dewi Ratna", nip: "199504042020042004", rank: "Pengatur", golongan: "II/c" },
  { id: 5, name: "Eko Prasetyo", nip: "198805052012051005", rank: "Penata Tingkat I", golongan: "III/d" },
  { id: 6, name: "Rina Wati", nip: "199206062016062006", rank: "Penata Muda Tk. I", golongan: "III/b" },
  { id: 7, name: "Joko Widodo", nip: "197807072002071007", rank: "Pembina Utama Muda", golongan: "IV/c" },
  { id: 8, name: "Megawati", nip: "198308082008082008", rank: "Pembina Tk. I", golongan: "IV/b" },
  { id: 9, name: "Susilo Bambang", nip: "197509091999091009", rank: "Pembina Utama Madya", golongan: "IV/d" },
  { id: 10, name: "Ani Yudhoyono", nip: "198610102011102010", rank: "Penata", golongan: "III/c" },
  { id: 20, name: "Anies Baswedan", nip: "198008202005081020", rank: "Pembina", golongan: "IV/a" }
];
const employeesStore = writable(DEFAULT_EMPLOYEES);
function generateRecords(count, employees) {
  const records = [];
  const now = /* @__PURE__ */ new Date();
  for (let i = 0; i < count; i++) {
    const isPast = Math.random() > 0.3;
    const dateOffset = isPast ? -Math.floor(Math.random() * 300) : Math.floor(Math.random() * 60);
    const startDate = new Date(now);
    startDate.setDate(now.getDate() + dateOffset);
    const duration = Math.floor(Math.random() * 4) + 2;
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + duration - 1);
    const loc = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
    const empList = employees.length > 0 ? employees : DEFAULT_EMPLOYEES;
    const emp = empList[Math.floor(Math.random() * empList.length)];
    const purpose = PURPOSES[Math.floor(Math.random() * PURPOSES.length)];
    let status = "Submitted";
    let reportStatus = "Pending";
    let reportData = null;
    let costs = {
      ticketGo: 0,
      ticketBack: 0,
      dailyAllowanceDays: 0,
      dailyAllowanceRate: 0,
      hotelDays: 0,
      hotelRate: 0,
      localTransport: 0,
      regionalTransport: 0,
      transportMode: "Pesawat"
    };
    let totalCost = 0;
    if (isPast) {
      status = Math.random() > 0.1 ? "Approved" : "Submitted";
      if (status === "Approved") {
        costs = {
          ticketGo: Math.floor(Math.random() * 2e6) + 1e6,
          ticketBack: Math.floor(Math.random() * 2e6) + 1e6,
          dailyAllowanceDays: duration,
          dailyAllowanceRate: 53e4,
          // Standard rate
          hotelDays: duration - 1,
          hotelRate: Math.floor(Math.random() * 8e5) + 4e5,
          localTransport: Math.floor(Math.random() * 3e5) + 1e5,
          regionalTransport: 0,
          transportMode: "Pesawat"
        };
        totalCost = costs.ticketGo + costs.ticketBack + costs.dailyAllowanceDays * costs.dailyAllowanceRate + costs.hotelDays * costs.hotelRate + costs.localTransport;
        if (Math.random() > 0.4) {
          reportStatus = "Completed";
          reportData = {
            text: `Kegiatan ${purpose} di ${loc.city} berjalan dengan lancar. Telah dilakukan koordinasi dengan pihak terkait dan disepakati beberapa poin penting untuk tindak lanjut.`,
            submittedAt: endDate.toISOString(),
            files: []
            // Mock empty files
          };
        }
      }
    }
    const spdNumber = Math.floor(Math.random() * 1e3).toString().padStart(3, "0");
    const month = startDate.getMonth() + 1;
    const romanMonth = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"][month - 1];
    const spd = `SPD-${spdNumber}/${romanMonth}/${startDate.getFullYear()}`;
    records.push({
      id: `PERDIN-${startDate.toISOString().slice(0, 10).replace(/-/g, "")}-${Math.floor(Math.random() * 1e3)}`,
      spd,
      employee: emp,
      email: "user@kemnaker.go.id",
      // Assign to demo user for visibility
      startDate: startDate.toISOString().split("T")[0],
      endDate: endDate.toISOString().split("T")[0],
      location: loc.city,
      province: loc.prov,
      purpose,
      stakeholder: "Menteri Ketenagakerjaan",
      agenda: `Melakukan ${purpose.toLowerCase()} bersama tim protokol dan pemda setempat.`,
      status,
      totalCost,
      costs,
      reportStatus,
      reportData
    });
  }
  return records.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
}
const initialData = generateRecords(50, DEFAULT_EMPLOYEES);
const recordsStore = writable(initialData);
export {
  employeesStore as e,
  recordsStore as r
};
