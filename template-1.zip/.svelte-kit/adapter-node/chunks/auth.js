import { w as writable } from "./index.js";
const initialUser = {
  email: null,
  role: null,
  loggedIn: false
};
const userStore = writable(initialUser);
const DEFAULT_USERS = [
  { id: 1, email: "user@kemnaker.go.id", password: "123456", role: "user", name: "Staf Pengaju" },
  { id: 2, email: "admin@kemnaker.go.id", password: "123456", role: "super_admin", name: "Super Admin" },
  { id: 3, email: "ppk@kemnaker.go.id", password: "123456", role: "ppk", name: "Pejabat Pembuat Komitmen" },
  { id: 4, email: "keuangan@kemnaker.go.id", password: "123456", role: "keuangan", name: "Admin Keuangan" }
];
const usersStore = writable(DEFAULT_USERS);
export {
  usersStore as a,
  userStore as u
};
