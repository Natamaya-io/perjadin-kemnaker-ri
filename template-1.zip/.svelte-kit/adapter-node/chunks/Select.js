import { i as sanitize_props, r as rest_props, j as fallback, c as slot, l as bind_props } from "./index2.js";
import { c as cn } from "./Button.js";
function Select($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["class", "value"]);
  $$renderer.component(($$renderer2) => {
    let classes;
    let className = fallback($$props["class"], void 0);
    let value = fallback($$props["value"], "");
    classes = cn("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 appearance-none", className);
    $$renderer2.push(`<div class="relative w-full">`);
    $$renderer2.select(
      { value, class: classes, ...$$restProps },
      ($$renderer3) => {
        $$renderer3.push(`<!--[-->`);
        slot($$renderer3, $$props, "default", {});
        $$renderer3.push(`<!--]-->`);
      },
      void 0,
      void 0,
      void 0,
      void 0,
      true
    );
    $$renderer2.push(` <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700"><svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"></path></svg></div></div>`);
    bind_props($$props, { class: className, value });
  });
}
export {
  Select as S
};
