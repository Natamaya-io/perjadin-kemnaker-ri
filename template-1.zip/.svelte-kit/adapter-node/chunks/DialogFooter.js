import { i as sanitize_props, r as rest_props, j as fallback, k as attributes, f as clsx, c as slot, l as bind_props } from "./index2.js";
import { c as cn } from "./Button.js";
function Table($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<div class="relative w-full overflow-auto"><table${attributes({
      class: clsx(cn("w-full caption-bottom text-sm", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></table></div>`);
    bind_props($$props, { className });
  });
}
function TableHeader($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<thead${attributes({
      class: clsx(cn("[&_tr]:border-b", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></thead>`);
    bind_props($$props, { className });
  });
}
function TableRow($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<tr${attributes({
      class: clsx(cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></tr>`);
    bind_props($$props, { className });
  });
}
function TableHead($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<th${attributes({
      class: clsx(cn("h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></th>`);
    bind_props($$props, { className });
  });
}
function TableBody($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<tbody${attributes({
      class: clsx(cn("[&_tr:last-child]:border-0", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></tbody>`);
    bind_props($$props, { className });
  });
}
function TableCell($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let className = fallback($$props["className"], "");
    $$renderer2.push(`<td${attributes({
      class: clsx(cn("p-4 align-middle [&:has([role=checkbox])]:pr-0", className)),
      ...$$restProps
    })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></td>`);
    bind_props($$props, { className });
  });
}
function DialogHeader($$renderer, $$props) {
  $$renderer.push(`<div class="flex flex-col space-y-1.5 text-center sm:text-left"><!--[-->`);
  slot($$renderer, $$props, "default", {});
  $$renderer.push(`<!--]--></div>`);
}
function DialogTitle($$renderer, $$props) {
  $$renderer.push(`<h2 class="text-lg font-semibold leading-none tracking-tight"><!--[-->`);
  slot($$renderer, $$props, "default", {});
  $$renderer.push(`<!--]--></h2>`);
}
function DialogFooter($$renderer, $$props) {
  $$renderer.push(`<div class="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2"><!--[-->`);
  slot($$renderer, $$props, "default", {});
  $$renderer.push(`<!--]--></div>`);
}
export {
  DialogHeader as D,
  Table as T,
  TableHeader as a,
  TableRow as b,
  TableHead as c,
  TableBody as d,
  TableCell as e,
  DialogTitle as f,
  DialogFooter as g
};
