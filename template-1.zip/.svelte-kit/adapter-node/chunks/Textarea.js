import { i as sanitize_props, r as rest_props, j as fallback, k as attributes, f as clsx, e as escape_html, l as bind_props } from "./index2.js";
import { c as cn } from "./Button.js";
function Textarea($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["class", "value"]);
  $$renderer.component(($$renderer2) => {
    let classes;
    let className = fallback($$props["class"], void 0);
    let value = fallback($$props["value"], "");
    classes = cn("flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className);
    $$renderer2.push(`<textarea${attributes({ class: clsx(classes), ...$$restProps })}>`);
    const $$body = escape_html(value);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea>`);
    bind_props($$props, { class: className, value });
  });
}
export {
  Textarea as T
};
