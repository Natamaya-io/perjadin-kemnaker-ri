import { i as sanitize_props, r as rest_props, j as fallback, k as attributes, f as clsx, c as slot, l as bind_props } from "./index2.js";
import { c as cn } from "./Button.js";
function Label($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["className"]);
  $$renderer.component(($$renderer2) => {
    let classes;
    let className = fallback($$props["className"], "");
    classes = cn("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", className);
    $$renderer2.push(`<label${attributes({ class: clsx(classes), ...$$restProps })}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></label>`);
    bind_props($$props, { className });
  });
}
export {
  Label as L
};
