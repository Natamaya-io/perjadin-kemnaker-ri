

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.CsuM9jD1.js","_app/immutable/chunks/CdlDsZfN.js","_app/immutable/chunks/C-urzYTY.js","_app/immutable/chunks/DaLd2v9u.js","_app/immutable/chunks/BtYpJXzj.js","_app/immutable/chunks/CWpCbKNV.js","_app/immutable/chunks/C0-vttmK.js","_app/immutable/chunks/CSa6v8Fz.js","_app/immutable/chunks/B_WvTedJ.js"];
export const stylesheets = [];
export const fonts = [];
