

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/dashboard/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.U-OXiIkR.js","_app/immutable/chunks/CdlDsZfN.js","_app/immutable/chunks/C-urzYTY.js","_app/immutable/chunks/DaLd2v9u.js","_app/immutable/chunks/By4eyi3J.js","_app/immutable/chunks/BpkXWWf1.js","_app/immutable/chunks/5NjwZR_O.js","_app/immutable/chunks/BurFZV44.js","_app/immutable/chunks/C0-vttmK.js","_app/immutable/chunks/BVApU8Gd.js","_app/immutable/chunks/CSa6v8Fz.js","_app/immutable/chunks/DZx9VO8s.js","_app/immutable/chunks/CWpCbKNV.js","_app/immutable/chunks/EK3Kanaa.js","_app/immutable/chunks/-7EHh0-Y.js"];
export const stylesheets = [];
export const fonts = [];
