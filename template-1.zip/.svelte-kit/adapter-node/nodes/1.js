

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.mYFbepZ-.js","_app/immutable/chunks/CdlDsZfN.js","_app/immutable/chunks/C-urzYTY.js","_app/immutable/chunks/DaLd2v9u.js","_app/immutable/chunks/By4eyi3J.js","_app/immutable/chunks/B_WvTedJ.js","_app/immutable/chunks/BtYpJXzj.js"];
export const stylesheets = [];
export const fonts = [];
