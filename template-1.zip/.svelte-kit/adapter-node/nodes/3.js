

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.3mVGqGHY.js","_app/immutable/chunks/CdlDsZfN.js","_app/immutable/chunks/C-urzYTY.js","_app/immutable/chunks/DaLd2v9u.js","_app/immutable/chunks/BtYpJXzj.js","_app/immutable/chunks/By4eyi3J.js","_app/immutable/chunks/BpkXWWf1.js","_app/immutable/chunks/Bi26uLOU.js","_app/immutable/chunks/EK3Kanaa.js","_app/immutable/chunks/BurFZV44.js","_app/immutable/chunks/C0-vttmK.js","_app/immutable/chunks/CSa6v8Fz.js"];
export const stylesheets = ["_app/immutable/assets/3.DJ1v4LbO.css"];
export const fonts = [];
