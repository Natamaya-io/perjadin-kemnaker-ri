import { s as store_get, d as ensure_array_like, e as escape_html, h as attr, u as unsubscribe_stores } from "../../../../../chunks/index2.js";
import { u as userStore } from "../../../../../chunks/auth.js";
import { w as writable } from "../../../../../chunks/index.js";
import { e as employeesStore } from "../../../../../chunks/records.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../../../chunks/root.js";
import "../../../../../chunks/state.svelte.js";
import { I as Input } from "../../../../../chunks/Input.js";
import { L as Label } from "../../../../../chunks/Label.js";
import { S as Select } from "../../../../../chunks/Select.js";
import { T as Textarea } from "../../../../../chunks/Textarea.js";
import "clsx";
import { B as Button } from "../../../../../chunks/Button.js";
const PROVINCES = [
  "Aceh",
  "Sumatera Utara",
  "Sumatera Barat",
  "Riau",
  "Jambi",
  "Sumatera Selatan",
  "Bengkulu",
  "Lampung",
  "Kepulauan Bangka Belitung",
  "Kepulauan Riau",
  "DKI Jakarta",
  "Jawa Barat",
  "Jawa Tengah",
  "DI Yogyakarta",
  "Jawa Timur",
  "Banten",
  "Bali",
  "Nusa Tenggara Barat",
  "Nusa Tenggara Timur",
  "Kalimantan Barat",
  "Kalimantan Tengah",
  "Kalimantan Selatan",
  "Kalimantan Timur",
  "Kalimantan Utara",
  "Sulawesi Utara",
  "Sulawesi Tengah",
  "Sulawesi Selatan",
  "Sulawesi Tenggara",
  "Gorontalo",
  "Sulawesi Barat",
  "Maluku",
  "Maluku Utara",
  "Papua",
  "Papua Barat",
  "Papua Selatan",
  "Papua Tengah",
  "Papua Pegunungan",
  "Papua Barat Daya"
];
const STAKEHOLDERS = [
  "Menteri Ketenagakerjaan",
  "Wakil Menteri Ketenagakerjaan",
  "Pendamping Menteri Ketenagakerjaan",
  "Pendamping Wakil Menteri Ketenagakerjaan"
];
const provincesStore = writable(PROVINCES);
const stakeholdersStore = writable(STAKEHOLDERS);
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let formData = {
      startDate: "",
      endDate: "",
      location: "",
      province: "",
      purpose: "persiapan",
      // Default
      stakeholder: "",
      agenda: "",
      selectedEmployees: []
    };
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="max-w-4xl mx-auto space-y-8 pb-20"><div class="space-y-2"><h1 class="text-3xl font-bold text-slate-900 tracking-tight">Pengajuan Baru</h1> <p class="text-slate-500">Buat draf perjalanan dinas dan protokol baru.</p></div> <div class="grid grid-cols-1 lg:grid-cols-3 gap-8"><div class="lg:col-span-2 space-y-6"><div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50"><h3 class="font-semibold text-slate-800 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> Informasi Dasar</h3></div> <div class="p-6 space-y-6"><div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Email Pengaju`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Input($$renderer3, {
        value: store_get($$store_subs ??= {}, "$userStore", userStore).email,
        readonly: true,
        disabled: true,
        class: "bg-slate-50 text-slate-500 border-slate-200"
      });
      $$renderer3.push(`<!----></div> <div class="grid grid-cols-1 sm:grid-cols-2 gap-6"><div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Tanggal Mulai <span class="text-red-500">*</span>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Input($$renderer3, {
        type: "date",
        required: true,
        class: "h-11",
        get value() {
          return formData.startDate;
        },
        set value($$value) {
          formData.startDate = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Tanggal Selesai <span class="text-red-500">*</span>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Input($$renderer3, {
        type: "date",
        required: true,
        class: "h-11",
        get value() {
          return formData.endDate;
        },
        set value($$value) {
          formData.endDate = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div></div></div></div> <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50"><h3 class="font-semibold text-slate-800 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg> Lokasi &amp; Tujuan</h3></div> <div class="p-6 space-y-6"><div class="grid grid-cols-1 sm:grid-cols-2 gap-6"><div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Lokasi Dinas (Kab/Kota)`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Input($$renderer3, {
        placeholder: "Contoh: Surabaya",
        class: "h-11",
        get value() {
          return formData.location;
        },
        set value($$value) {
          formData.location = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Provinsi <span class="text-red-500">*</span>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Select($$renderer3, {
        class: "h-11",
        get value() {
          return formData.province;
        },
        set value($$value) {
          formData.province = $$value;
          $$settled = false;
        },
        children: ($$renderer4) => {
          $$renderer4.option({ value: "", disabled: true, selected: true }, ($$renderer5) => {
            $$renderer5.push(`Pilih Provinsi`);
          });
          $$renderer4.push(` <!--[-->`);
          const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$provincesStore", provincesStore));
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let province = each_array[$$index];
            $$renderer4.option({ value: province }, ($$renderer5) => {
              $$renderer5.push(`${escape_html(province)}`);
            });
          }
          $$renderer4.push(`<!--]-->`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div> <div class="space-y-3">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Tujuan Perjalanan`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> <div class="grid grid-cols-1 gap-3"><label class="relative flex items-center p-4 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors has-[:checked]:border-blue-500 has-[:checked]:bg-blue-50/30"><input type="radio" name="purpose" value="persiapan"${attr("checked", formData.purpose === "persiapan", true)} class="accent-blue-600 h-4 w-4 mr-3"/> <span class="text-sm font-medium text-slate-700">Persiapan dan Pendampingan Kunjungan Kerja</span></label> <label class="relative flex items-center p-4 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors has-[:checked]:border-blue-500 has-[:checked]:bg-blue-50/30"><input type="radio" name="purpose" value="koordinasi"${attr("checked", formData.purpose === "koordinasi", true)} class="accent-blue-600 h-4 w-4 mr-3"/> <span class="text-sm font-medium text-slate-700">Koordinasi dan Konsultasi Kunjungan Kerja</span></label></div></div> <div class="space-y-2">`);
      Label($$renderer3, {
        class: "text-slate-600",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Detail Agenda`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> `);
      Textarea($$renderer3, {
        placeholder: "Jelaskan detail agenda kegiatan secara singkat...",
        class: "min-h-[100px] resize-y",
        get value() {
          return formData.agenda;
        },
        set value($$value) {
          formData.agenda = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div></div></div></div> <div class="lg:col-span-1 space-y-6"><div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50"><h3 class="font-semibold text-slate-800">Stakeholder Terkait</h3></div> <div class="p-6 space-y-3"><!--[-->`);
      const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$stakeholdersStore", stakeholdersStore));
      for (let i = 0, $$length = each_array_1.length; i < $$length; i++) {
        let sh = each_array_1[i];
        $$renderer3.push(`<label class="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"><input type="radio" name="stakeholder"${attr("value", sh)}${attr("checked", formData.stakeholder === sh, true)} class="mt-1 accent-blue-600 h-4 w-4 shrink-0"/> <span class="text-sm text-slate-600 leading-snug">${escape_html(sh)}</span></label>`);
      }
      $$renderer3.push(`<!--]--></div></div> <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[500px]"><div class="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center"><h3 class="font-semibold text-slate-800">Pilih Petugas</h3> <span class="text-xs font-medium px-2 py-1 bg-blue-100 text-blue-700 rounded-full">${escape_html(formData.selectedEmployees.length)}/6</span></div> <div class="p-4 overflow-y-auto flex-1 space-y-2"><!--[-->`);
      const each_array_2 = ensure_array_like(store_get($$store_subs ??= {}, "$employeesStore", employeesStore));
      for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
        let employee = each_array_2[$$index_2];
        $$renderer3.push(`<label class="flex items-center space-x-3 p-3 rounded-lg border border-transparent hover:border-slate-200 hover:bg-slate-50 transition-all cursor-pointer has-[:checked]:bg-blue-50/30 has-[:checked]:border-blue-200"><input type="checkbox"${attr("checked", formData.selectedEmployees.includes(employee.id), true)} class="accent-blue-600 h-5 w-5 rounded border-slate-300 shrink-0"/> <div class="grid gap-0.5"><span class="text-sm font-semibold text-slate-800">${escape_html(employee.name)}</span> <span class="text-xs text-slate-500">${escape_html(employee.rank)} - ${escape_html(employee.golongan)}</span></div></label>`);
      }
      $$renderer3.push(`<!--]--></div> <div class="p-4 border-t border-slate-100 bg-slate-50/50"><p class="text-xs text-slate-500 text-center mb-3">Pastikan data sudah benar sebelum menyimpan.</p> `);
      Button($$renderer3, {
        class: "w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Simpan Pengajuan`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div></div></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
