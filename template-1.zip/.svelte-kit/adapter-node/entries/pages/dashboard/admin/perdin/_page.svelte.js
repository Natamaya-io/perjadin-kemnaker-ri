import { s as store_get, u as unsubscribe_stores, d as ensure_array_like, e as escape_html, a as attr_class, f as clsx, h as attr, b as stringify } from "../../../../../chunks/index2.js";
import { r as recordsStore } from "../../../../../chunks/records.js";
import { u as userStore } from "../../../../../chunks/auth.js";
import { c as cn, B as Button } from "../../../../../chunks/Button.js";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell, D as DialogHeader, f as DialogTitle, g as DialogFooter } from "../../../../../chunks/DialogFooter.js";
import { D as Dialog } from "../../../../../chunks/Dialog.js";
import { L as Label } from "../../../../../chunks/Label.js";
import { I as Input } from "../../../../../chunks/Input.js";
import { S as Select } from "../../../../../chunks/Select.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let filteredRecords, totalDailyAllowance, totalHotel, totalTicket, totalLocal, totalRegional, grandTotal;
    let isModalOpen = false;
    let selectedRecord = null;
    let editingCosts = {
      ticketGo: 0,
      ticketBack: 0,
      dailyAllowanceDays: 0,
      dailyAllowanceRate: 0,
      hotelDays: 0,
      hotelRate: 0,
      localTransport: 0,
      regionalTransport: 0,
      transportMode: "Pesawat"
    };
    let searchQuery = "";
    let statusFilter = "all";
    let sortOption = "date-desc";
    function formatCurrency(amount) {
      return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(amount);
    }
    filteredRecords = store_get($$store_subs ??= {}, "$recordsStore", recordsStore).filter((r) => {
      const query = searchQuery.toLowerCase();
      const matchSearch = r.employee.name.toLowerCase().includes(query) || r.spd.toLowerCase().includes(query) || r.location.toLowerCase().includes(query);
      const matchStatus = statusFilter === "all" || r.status === statusFilter;
      return matchSearch && matchStatus;
    }).sort((a, b) => {
      if (sortOption === "date-desc") return new Date(b.startDate) - new Date(a.startDate);
      if (sortOption === "date-asc") return new Date(a.startDate) - new Date(b.startDate);
      if (sortOption === "cost-desc") return b.totalCost - a.totalCost;
      if (sortOption === "cost-asc") return a.totalCost - b.totalCost;
      return 0;
    });
    totalDailyAllowance = editingCosts.dailyAllowanceDays * editingCosts.dailyAllowanceRate;
    totalHotel = editingCosts.hotelDays * editingCosts.hotelRate;
    totalTicket = Number(editingCosts.ticketGo) + Number(editingCosts.ticketBack);
    totalLocal = Number(editingCosts.localTransport);
    totalRegional = Number(editingCosts.regionalTransport);
    grandTotal = totalTicket + totalDailyAllowance + totalHotel + totalLocal + totalRegional;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="space-y-6 pb-20"><div class="flex flex-col md:flex-row md:items-center justify-between gap-4"><div><h2 class="text-2xl font-bold tracking-tight text-slate-900">Rekap &amp; Kalkulasi</h2> <p class="text-slate-500">Kelola pengajuan dan hitung rincian biaya.</p></div> <div class="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full md:w-auto"><div class="relative w-full md:w-64"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></div> `);
      Input($$renderer3, {
        type: "text",
        placeholder: "Cari Nama, SPD, Tujuan...",
        class: "pl-9 h-9 text-sm bg-white border-slate-200 w-full",
        get value() {
          return searchQuery;
        },
        set value($$value) {
          searchQuery = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div class="flex space-x-2 w-full sm:w-auto"><div class="w-1/2 sm:w-32">`);
      Select($$renderer3, {
        class: "h-9 text-xs w-full bg-white border-slate-200",
        get value() {
          return statusFilter;
        },
        set value($$value) {
          statusFilter = $$value;
          $$settled = false;
        },
        children: ($$renderer4) => {
          $$renderer4.option({ value: "all" }, ($$renderer5) => {
            $$renderer5.push(`Semua Status`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "Submitted" }, ($$renderer5) => {
            $$renderer5.push(`Submitted`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "Approved" }, ($$renderer5) => {
            $$renderer5.push(`Approved`);
          });
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div> <div class="w-1/2 sm:w-40">`);
      Select($$renderer3, {
        class: "h-9 text-xs w-full bg-white border-slate-200",
        get value() {
          return sortOption;
        },
        set value($$value) {
          sortOption = $$value;
          $$settled = false;
        },
        children: ($$renderer4) => {
          $$renderer4.option({ value: "date-desc" }, ($$renderer5) => {
            $$renderer5.push(`Terbaru`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "date-asc" }, ($$renderer5) => {
            $$renderer5.push(`Terlama`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "cost-desc" }, ($$renderer5) => {
            $$renderer5.push(`Biaya Tertinggi`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "cost-asc" }, ($$renderer5) => {
            $$renderer5.push(`Biaya Terendah`);
          });
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div></div></div> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role !== "super_admin" && store_get($$store_subs ??= {}, "$userStore", userStore).role !== "keuangan") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50"><svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-slate-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg> <h3 class="text-lg font-medium text-slate-900">Akses Dibatasi</h3> <p class="text-slate-500 max-w-sm mt-1">Halaman ini khusus untuk Admin Keuangan. Silakan login dengan akun yang sesuai.</p></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="grid grid-cols-1 gap-4 md:hidden"><!--[-->`);
        const each_array = ensure_array_like(filteredRecords);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let record = each_array[$$index];
          $$renderer3.push(`<div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4"><div class="flex justify-between items-start"><div><span class="text-xs font-mono text-slate-400 block mb-1">${escape_html(record.spd)}</span> <h3 class="font-bold text-slate-800">${escape_html(record.employee.name)}</h3> <p class="text-xs text-slate-500">${escape_html(record.employee.rank)} (${escape_html(record.employee.golongan)})</p></div> <span${attr_class(clsx(cn("px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide", record.status === "Submitted" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700")))}>${escape_html(record.status)}</span></div> <div class="border-t border-b border-slate-50 py-3 space-y-2"><div class="flex justify-between text-sm"><span class="text-slate-500">Tujuan</span> <span class="font-medium text-slate-700 text-right">${escape_html(record.location)}</span></div> <div class="flex justify-between text-sm"><span class="text-slate-500">Tanggal</span> <span class="font-medium text-slate-700">${escape_html(record.startDate)}</span></div> <div class="flex justify-between text-sm pt-2"><span class="text-slate-500 font-semibold">Total Biaya</span> <span class="font-bold text-blue-600">${escape_html(formatCurrency(record.totalCost))}</span></div></div> <div class="grid grid-cols-3 gap-2">`);
          Button($$renderer3, {
            variant: "outline",
            size: "sm",
            class: "w-full text-xs h-9",
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Hitung`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            class: "w-full text-xs h-9 bg-slate-50 hover:bg-slate-100 text-slate-600",
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->SPD`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          Button($$renderer3, {
            variant: "ghost",
            size: "sm",
            class: "w-full text-xs h-9 bg-slate-50 hover:bg-slate-100 text-slate-600",
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->Rincian`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></div></div>`);
        }
        $$renderer3.push(`<!--]--></div> <div class="hidden md:block rounded-xl border border-slate-200 shadow-sm bg-white overflow-hidden"><div class="overflow-x-auto w-full">`);
        Table($$renderer3, {
          class: "w-full text-sm text-left",
          children: ($$renderer4) => {
            TableHeader($$renderer4, {
              class: "bg-slate-50 border-b border-slate-200",
              children: ($$renderer5) => {
                TableRow($$renderer5, {
                  class: "hover:bg-slate-50/50",
                  children: ($$renderer6) => {
                    TableHead($$renderer6, {
                      class: "w-[100px] min-w-[100px] font-semibold text-slate-700 pl-4 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->ID / SPD`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "min-w-[200px] font-semibold text-slate-700 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Pegawai`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "min-w-[250px] font-semibold text-slate-700 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Detail Perjalanan`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "w-[120px] min-w-[120px] font-semibold text-slate-700 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Status`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "min-w-[160px] font-semibold text-slate-700 text-right py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Total Biaya`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "w-[180px] min-w-[180px] font-semibold text-slate-700 text-right pr-4 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Aksi`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!---->`);
                  },
                  $$slots: { default: true }
                });
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            TableBody($$renderer4, {
              children: ($$renderer5) => {
                $$renderer5.push(`<!--[-->`);
                const each_array_1 = ensure_array_like(filteredRecords);
                for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
                  let record = each_array_1[$$index_1];
                  TableRow($$renderer5, {
                    class: "hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0",
                    children: ($$renderer6) => {
                      TableCell($$renderer6, {
                        class: "pl-4 py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<div class="flex flex-col gap-0.5"><span class="font-mono text-[10px] text-slate-400 leading-none">#${escape_html(record.id)}</span> <span class="font-medium text-xs text-slate-700">${escape_html(record.spd)}</span></div>`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!----> `);
                      TableCell($$renderer6, {
                        class: "py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<div class="flex flex-col gap-0.5"><span class="font-semibold text-slate-900 text-sm">${escape_html(record.employee.name)}</span> <span class="text-xs text-slate-500">${escape_html(record.employee.rank)}</span></div>`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!----> `);
                      TableCell($$renderer6, {
                        class: "py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<div class="flex flex-col gap-0.5 max-w-[250px]"><span class="font-medium text-slate-700 text-sm truncate"${attr("title", `${stringify(record.location)}, ${stringify(record.province)}`)}>${escape_html(record.location)}, ${escape_html(record.province)}</span> <span class="text-xs text-slate-500 flex items-center gap-1"><svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg> ${escape_html(record.startDate)} s/d ${escape_html(record.endDate)}</span></div>`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!----> `);
                      TableCell($$renderer6, {
                        class: "py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<span${attr_class(clsx(cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide border", record.status === "Submitted" ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-emerald-50 text-emerald-700 border-emerald-200")))}>${escape_html(record.status)}</span>`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!----> `);
                      TableCell($$renderer6, {
                        class: "text-right font-mono font-medium text-slate-700 py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<!---->${escape_html(formatCurrency(record.totalCost))}`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!----> `);
                      TableCell($$renderer6, {
                        class: "text-right pr-4 py-3 align-top",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<div class="flex justify-end items-center gap-1">`);
                          Button($$renderer7, {
                            variant: "outline",
                            size: "sm",
                            class: "h-8 text-xs border-slate-200 bg-white hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm",
                            children: ($$renderer8) => {
                              $$renderer8.push(`<!---->Hitung`);
                            },
                            $$slots: { default: true }
                          });
                          $$renderer7.push(`<!----> <div class="h-4 w-px bg-slate-200 mx-1"></div> <div class="flex items-center gap-1"><button class="p-1.5 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-700 transition-colors" title="Cetak SPD"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" x2="8" y1="13" y2="13"></line><line x1="16" x2="8" y1="17" y2="17"></line><line x1="10" x2="8" y1="9" y2="9"></line></svg></button> <button class="p-1.5 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-700 transition-colors" title="Cetak Rincian"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2"></rect><line x1="8" x2="16" y1="6" y2="6"></line><line x1="16" x2="16" y1="14" y2="18"></line><path d="M16 10h.01"></path><path d="M12 10h.01"></path><path d="M8 10h.01"></path><path d="M12 14h.01"></path><path d="M8 14h.01"></path><path d="M12 18h.01"></path><path d="M8 18h.01"></path></svg></button></div></div>`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer6.push(`<!---->`);
                    },
                    $$slots: { default: true }
                  });
                }
                $$renderer5.push(`<!--]-->`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div></div>`);
      }
      $$renderer3.push(`<!--]--> `);
      Dialog($$renderer3, {
        open: isModalOpen,
        children: ($$renderer4) => {
          DialogHeader($$renderer4, {
            class: "border-b border-slate-100 pb-4",
            children: ($$renderer5) => {
              DialogTitle($$renderer5, {
                class: "text-xl",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->Input Rincian Biaya`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!----> <p class="text-sm text-slate-500">Lengkapi komponen biaya untuk <span class="font-semibold text-slate-800">${escape_html(selectedRecord?.employee?.name)}</span>.</p>`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="grid gap-6 py-6 max-h-[60vh] overflow-y-auto pr-2"><div class="grid grid-cols-1 sm:grid-cols-2 gap-4"><div class="space-y-2">`);
          Label($$renderer4, {
            class: "text-xs font-semibold uppercase text-slate-500 tracking-wider",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Tiket Berangkat`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-slate-50 border-slate-200 focus:bg-white",
            get value() {
              return editingCosts.ticketGo;
            },
            set value($$value) {
              editingCosts.ticketGo = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div></div> <div class="space-y-2">`);
          Label($$renderer4, {
            class: "text-xs font-semibold uppercase text-slate-500 tracking-wider",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Tiket Pulang`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-slate-50 border-slate-200 focus:bg-white",
            get value() {
              return editingCosts.ticketBack;
            },
            set value($$value) {
              editingCosts.ticketBack = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div></div></div> <div class="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-4"><h4 class="text-sm font-semibold text-slate-700 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> Uang Harian</h4> <div class="grid grid-cols-1 sm:grid-cols-3 gap-4"><div class="space-y-2 col-span-1">`);
          Label($$renderer4, {
            class: "text-xs text-slate-500",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Durasi (Hari)`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Input($$renderer4, {
            type: "number",
            class: "bg-white border-slate-200",
            get value() {
              return editingCosts.dailyAllowanceDays;
            },
            set value($$value) {
              editingCosts.dailyAllowanceDays = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <div class="space-y-2 col-span-1 sm:col-span-2">`);
          Label($$renderer4, {
            class: "text-xs text-slate-500",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Rate per Hari`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-white border-slate-200",
            get value() {
              return editingCosts.dailyAllowanceRate;
            },
            set value($$value) {
              editingCosts.dailyAllowanceRate = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div></div></div> <div class="text-right text-sm font-mono font-medium text-slate-600 border-t border-slate-200 pt-2 mt-2">Subtotal: ${escape_html(formatCurrency(editingCosts.dailyAllowanceDays * editingCosts.dailyAllowanceRate))}</div></div> <div class="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-4"><h4 class="text-sm font-semibold text-slate-700 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg> Penginapan</h4> <div class="grid grid-cols-1 sm:grid-cols-3 gap-4"><div class="space-y-2 col-span-1">`);
          Label($$renderer4, {
            class: "text-xs text-slate-500",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Durasi (Malam)`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Input($$renderer4, {
            type: "number",
            class: "bg-white border-slate-200",
            get value() {
              return editingCosts.hotelDays;
            },
            set value($$value) {
              editingCosts.hotelDays = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <div class="space-y-2 col-span-1 sm:col-span-2">`);
          Label($$renderer4, {
            class: "text-xs text-slate-500",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Rate per Malam`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-white border-slate-200",
            get value() {
              return editingCosts.hotelRate;
            },
            set value($$value) {
              editingCosts.hotelRate = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div></div></div> <div class="text-right text-sm font-mono font-medium text-slate-600 border-t border-slate-200 pt-2 mt-2">Subtotal: ${escape_html(formatCurrency(editingCosts.hotelDays * editingCosts.hotelRate))}</div></div> <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2"><div class="space-y-2">`);
          Label($$renderer4, {
            class: "text-xs font-semibold uppercase text-slate-500 tracking-wider",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Transport Lokal`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-slate-50 border-slate-200 focus:bg-white",
            get value() {
              return editingCosts.localTransport;
            },
            set value($$value) {
              editingCosts.localTransport = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <p class="text-[10px] text-slate-400">Maks. Rp 500.000</p></div> <div class="space-y-2">`);
          Label($$renderer4, {
            class: "text-xs font-semibold uppercase text-slate-500 tracking-wider",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Transport Daerah`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative"><span class="absolute left-3 top-2.5 text-slate-400 text-sm">Rp</span> `);
          Input($$renderer4, {
            type: "number",
            class: "pl-9 bg-slate-50 border-slate-200 focus:bg-white",
            get value() {
              return editingCosts.regionalTransport;
            },
            set value($$value) {
              editingCosts.regionalTransport = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div></div></div> <div class="space-y-2 pt-2">`);
          Label($$renderer4, {
            class: "text-xs font-semibold uppercase text-slate-500 tracking-wider",
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Mode Transportasi`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Select($$renderer4, {
            class: "bg-slate-50 border-slate-200",
            get value() {
              return editingCosts.transportMode;
            },
            set value($$value) {
              editingCosts.transportMode = $$value;
              $$settled = false;
            },
            children: ($$renderer5) => {
              $$renderer5.option({ value: "Pesawat" }, ($$renderer6) => {
                $$renderer6.push(`Pesawat Udara`);
              });
              $$renderer5.push(` `);
              $$renderer5.option({ value: "Kendaraan Umum" }, ($$renderer6) => {
                $$renderer6.push(`Kendaraan Umum / Kereta`);
              });
              $$renderer5.push(` `);
              $$renderer5.option({ value: "Kendaraan Dinas" }, ($$renderer6) => {
                $$renderer6.push(`Kendaraan Dinas`);
              });
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----></div></div> `);
          DialogFooter($$renderer4, {
            children: ($$renderer5) => {
              $$renderer5.push(`<div class="w-full flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100 pt-4"><div class="w-full sm:w-auto flex justify-between sm:block text-left"><span class="block text-xs text-slate-500 self-center sm:self-auto">Total Estimasi</span> <span class="text-lg font-bold text-blue-600">${escape_html(formatCurrency(grandTotal))}</span></div> <div class="flex gap-2 w-full sm:w-auto">`);
              Button($$renderer5, {
                variant: "outline",
                class: "flex-1 sm:flex-none border-slate-200 text-slate-600",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->Batal`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!----> `);
              Button($$renderer5, {
                class: "flex-1 sm:flex-none bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->Simpan`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!----></div></div>`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!---->`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
