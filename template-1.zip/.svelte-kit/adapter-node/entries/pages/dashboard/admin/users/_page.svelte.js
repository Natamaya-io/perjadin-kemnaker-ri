import { s as store_get, u as unsubscribe_stores, d as ensure_array_like, e as escape_html, a as attr_class, f as clsx } from "../../../../../chunks/index2.js";
import { a as usersStore, u as userStore } from "../../../../../chunks/auth.js";
import { B as Button, c as cn } from "../../../../../chunks/Button.js";
import { I as Input } from "../../../../../chunks/Input.js";
import { L as Label } from "../../../../../chunks/Label.js";
import { D as Dialog } from "../../../../../chunks/Dialog.js";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell, D as DialogHeader, f as DialogTitle, g as DialogFooter } from "../../../../../chunks/DialogFooter.js";
import { S as Select } from "../../../../../chunks/Select.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let filteredUsers;
    let searchQuery = "";
    let isModalOpen = false;
    let formData = { name: "", email: "", password: "", role: "user" };
    filteredUsers = store_get($$store_subs ??= {}, "$usersStore", usersStore).filter((u) => u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase()));
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="space-y-6 pb-20"><div class="flex flex-col md:flex-row md:items-center justify-between gap-4"><div><h2 class="text-2xl font-bold tracking-tight text-slate-900">Manajemen User</h2> <p class="text-slate-500">Kelola akun pengguna dan hak akses aplikasi.</p></div> <div class="flex items-center space-x-2 w-full md:w-auto">`);
      Button($$renderer3, {
        class: "bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20",
        children: ($$renderer4) => {
          $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg> Tambah User`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role !== "super_admin") {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50"><svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-slate-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg> <h3 class="text-lg font-medium text-slate-900">Akses Dibatasi</h3> <p class="text-slate-500 max-w-sm mt-1">Halaman ini khusus untuk Super Admin. Silakan login dengan akun yang sesuai.</p></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="relative w-full md:w-96"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></div> `);
        Input($$renderer3, {
          type: "text",
          placeholder: "Cari Nama atau Email...",
          class: "pl-9 bg-white border-slate-200",
          get value() {
            return searchQuery;
          },
          set value($$value) {
            searchQuery = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----></div> <div class="hidden md:block rounded-xl border border-slate-200 shadow-sm bg-white overflow-hidden"><div class="overflow-x-auto w-full">`);
        Table($$renderer3, {
          class: "w-full text-sm text-left",
          children: ($$renderer4) => {
            TableHeader($$renderer4, {
              class: "bg-slate-50 border-b border-slate-200",
              children: ($$renderer5) => {
                TableRow($$renderer5, {
                  class: "hover:bg-slate-50/50",
                  children: ($$renderer6) => {
                    TableHead($$renderer6, {
                      class: "min-w-[200px] font-semibold text-slate-700 pl-4 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Nama User`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "min-w-[200px] font-semibold text-slate-700 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Email`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "min-w-[150px] font-semibold text-slate-700 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Role`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!----> `);
                    TableHead($$renderer6, {
                      class: "w-[100px] min-w-[100px] font-semibold text-slate-700 text-right pr-4 py-3",
                      children: ($$renderer7) => {
                        $$renderer7.push(`<!---->Aksi`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer6.push(`<!---->`);
                  },
                  $$slots: { default: true }
                });
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            TableBody($$renderer4, {
              children: ($$renderer5) => {
                if (filteredUsers.length === 0) {
                  $$renderer5.push("<!--[-->");
                  TableRow($$renderer5, {
                    children: ($$renderer6) => {
                      TableCell($$renderer6, {
                        colspan: "4",
                        class: "text-center py-12 text-slate-500 italic bg-slate-50/20",
                        children: ($$renderer7) => {
                          $$renderer7.push(`<div class="flex flex-col items-center justify-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg> <span>Tidak ada user ditemukan.</span></div>`);
                        },
                        $$slots: { default: true }
                      });
                    },
                    $$slots: { default: true }
                  });
                } else {
                  $$renderer5.push("<!--[!-->");
                  $$renderer5.push(`<!--[-->`);
                  const each_array = ensure_array_like(filteredUsers);
                  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                    let user = each_array[$$index];
                    TableRow($$renderer5, {
                      class: "hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0",
                      children: ($$renderer6) => {
                        TableCell($$renderer6, {
                          class: "pl-4 py-3 font-medium text-slate-900",
                          children: ($$renderer7) => {
                            $$renderer7.push(`<!---->${escape_html(user.name)}`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!----> `);
                        TableCell($$renderer6, {
                          class: "py-3 text-slate-600",
                          children: ($$renderer7) => {
                            $$renderer7.push(`<!---->${escape_html(user.email)}`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!----> `);
                        TableCell($$renderer6, {
                          class: "py-3",
                          children: ($$renderer7) => {
                            $$renderer7.push(`<span${attr_class(clsx(cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide border", user.role === "super_admin" ? "bg-purple-50 text-purple-700 border-purple-200" : user.role === "keuangan" ? "bg-indigo-50 text-indigo-700 border-indigo-200" : user.role === "ppk" ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-blue-50 text-blue-700 border-blue-200")))}>${escape_html(user.role)}</span>`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!----> `);
                        TableCell($$renderer6, {
                          class: "text-right pr-4 py-3",
                          children: ($$renderer7) => {
                            $$renderer7.push(`<div class="flex justify-end items-center gap-1"><button class="p-1.5 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="Edit"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg></button> <button class="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors" title="Hapus"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button></div>`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!---->`);
                      },
                      $$slots: { default: true }
                    });
                  }
                  $$renderer5.push(`<!--]-->`);
                }
                $$renderer5.push(`<!--]-->`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div></div> <div class="grid grid-cols-1 gap-4 md:hidden">`);
        if (filteredUsers.length === 0) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<div class="text-center py-8 text-slate-500 italic bg-white rounded-xl border border-slate-200">Tidak ada user ditemukan.</div>`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<!--[-->`);
          const each_array_1 = ensure_array_like(filteredUsers);
          for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
            let user = each_array_1[$$index_1];
            $$renderer3.push(`<div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 relative"><div class="absolute top-4 right-4 flex gap-2"><button class="text-slate-400 hover:text-blue-600"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg></button> <button class="text-slate-400 hover:text-red-600"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button></div> <div><h3 class="font-bold text-slate-800">${escape_html(user.name)}</h3> <p class="text-xs font-mono text-slate-500 mt-1">${escape_html(user.email)}</p></div> <div class="flex gap-4 text-sm text-slate-600 border-t border-slate-50 pt-2"><span${attr_class(clsx(cn("px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide", user.role === "super_admin" ? "bg-purple-100 text-purple-700" : user.role === "keuangan" ? "bg-indigo-100 text-indigo-700" : user.role === "ppk" ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700")))}>${escape_html(user.role)}</span></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        }
        $$renderer3.push(`<!--]--></div>`);
      }
      $$renderer3.push(`<!--]--> `);
      Dialog($$renderer3, {
        open: isModalOpen,
        children: ($$renderer4) => {
          DialogHeader($$renderer4, {
            class: "border-b border-slate-100 pb-4",
            children: ($$renderer5) => {
              DialogTitle($$renderer5, {
                class: "text-xl",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->${escape_html("Tambah")} User`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!----> <p class="text-sm text-slate-500">Lengkapi data akun pengguna.</p>`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="space-y-4 py-4"><div class="space-y-2">`);
          Label($$renderer4, {
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Nama Lengkap`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Input($$renderer4, {
            type: "text",
            placeholder: "Contoh: Staf Pengaju",
            get value() {
              return formData.name;
            },
            set value($$value) {
              formData.name = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <div class="space-y-2">`);
          Label($$renderer4, {
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Email Kedinasan`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Input($$renderer4, {
            type: "email",
            placeholder: "nama@kemnaker.go.id",
            get value() {
              return formData.email;
            },
            set value($$value) {
              formData.email = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <div class="space-y-2">`);
          Label($$renderer4, {
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Password`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> `);
          Input($$renderer4, {
            type: "text",
            placeholder: "Minimal 6 karakter",
            get value() {
              return formData.password;
            },
            set value($$value) {
              formData.password = $$value;
              $$settled = false;
            }
          });
          $$renderer4.push(`<!----></div> <div class="space-y-2">`);
          Label($$renderer4, {
            children: ($$renderer5) => {
              $$renderer5.push(`<!---->Role (Hak Akses)`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----> <div class="relative w-full">`);
          Select($$renderer4, {
            class: "bg-white border-slate-200",
            get value() {
              return formData.role;
            },
            set value($$value) {
              formData.role = $$value;
              $$settled = false;
            },
            children: ($$renderer5) => {
              $$renderer5.option({ value: "user" }, ($$renderer6) => {
                $$renderer6.push(`User (Staf Pengaju)`);
              });
              $$renderer5.push(` `);
              $$renderer5.option({ value: "super_admin" }, ($$renderer6) => {
                $$renderer6.push(`Super Admin`);
              });
              $$renderer5.push(` `);
              $$renderer5.option({ value: "keuangan" }, ($$renderer6) => {
                $$renderer6.push(`Admin Keuangan`);
              });
              $$renderer5.push(` `);
              $$renderer5.option({ value: "ppk" }, ($$renderer6) => {
                $$renderer6.push(`Pejabat Pembuat Komitmen (PPK)`);
              });
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!----></div></div></div> `);
          DialogFooter($$renderer4, {
            class: "border-t border-slate-100 pt-4 flex justify-end gap-2",
            children: ($$renderer5) => {
              Button($$renderer5, {
                variant: "outline",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->Batal`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!----> `);
              Button($$renderer5, {
                class: "bg-blue-600 hover:bg-blue-700 text-white",
                children: ($$renderer6) => {
                  $$renderer6.push(`<!---->Simpan`);
                },
                $$slots: { default: true }
              });
              $$renderer5.push(`<!---->`);
            },
            $$slots: { default: true }
          });
          $$renderer4.push(`<!---->`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
