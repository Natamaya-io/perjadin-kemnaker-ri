import { s as store_get, u as unsubscribe_stores, d as ensure_array_like, a as attr_class, f as clsx, e as escape_html, h as attr } from "../../../../chunks/index2.js";
import { r as recordsStore } from "../../../../chunks/records.js";
import { u as userStore } from "../../../../chunks/auth.js";
import { c as cn, g as getInitials, B as Button } from "../../../../chunks/Button.js";
import { I as Input } from "../../../../chunks/Input.js";
import { S as Select } from "../../../../chunks/Select.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let myRecords, filteredRecords;
    let searchQuery = "";
    let statusFilter = "all";
    let sortOption = "date-desc";
    myRecords = store_get($$store_subs ??= {}, "$recordsStore", recordsStore).filter((r) => r.email === store_get($$store_subs ??= {}, "$userStore", userStore).email || store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin" || store_get($$store_subs ??= {}, "$userStore", userStore).role === "keuangan");
    filteredRecords = myRecords.filter((r) => {
      const query = searchQuery.toLowerCase();
      const matchSearch = r.purpose.toLowerCase().includes(query) || r.location.toLowerCase().includes(query) || r.spd.toLowerCase().includes(query);
      const matchStatus = statusFilter === "all" || r.reportStatus === statusFilter;
      return matchSearch && matchStatus;
    }).sort((a, b) => {
      if (sortOption === "date-desc") return new Date(b.startDate) - new Date(a.startDate);
      if (sortOption === "date-asc") return new Date(a.startDate) - new Date(b.startDate);
      return 0;
    });
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="space-y-8 pb-20"><div class="flex flex-col md:flex-row md:items-end justify-between gap-4"><div class="space-y-2"><h2 class="text-3xl font-bold tracking-tight text-slate-900">Laporan Pasca Dinas</h2> <p class="text-slate-500 max-w-2xl">Unggah dokumentasi dan laporan kegiatan perjalanan dinas yang telah diselesaikan.</p></div> <div class="flex flex-col sm:flex-row gap-2 w-full md:w-auto"><div class="relative w-full md:w-64"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></div> `);
      Input($$renderer3, {
        type: "text",
        placeholder: "Cari Kegiatan, Lokasi, SPD...",
        class: "pl-9 h-10 bg-white border-slate-200 w-full",
        get value() {
          return searchQuery;
        },
        set value($$value) {
          searchQuery = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div> <div class="flex gap-2 w-full sm:w-auto"><div class="w-1/2 sm:w-32">`);
      Select($$renderer3, {
        class: "h-10 text-xs w-full bg-white border-slate-200",
        get value() {
          return statusFilter;
        },
        set value($$value) {
          statusFilter = $$value;
          $$settled = false;
        },
        children: ($$renderer4) => {
          $$renderer4.option({ value: "all" }, ($$renderer5) => {
            $$renderer5.push(`Semua Status`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "Completed" }, ($$renderer5) => {
            $$renderer5.push(`Selesai`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "Pending" }, ($$renderer5) => {
            $$renderer5.push(`Pending`);
          });
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div> <div class="w-1/2 sm:w-36">`);
      Select($$renderer3, {
        class: "h-10 text-xs w-full bg-white border-slate-200",
        get value() {
          return sortOption;
        },
        set value($$value) {
          sortOption = $$value;
          $$settled = false;
        },
        children: ($$renderer4) => {
          $$renderer4.option({ value: "date-desc" }, ($$renderer5) => {
            $$renderer5.push(`Terbaru`);
          });
          $$renderer4.push(` `);
          $$renderer4.option({ value: "date-asc" }, ($$renderer5) => {
            $$renderer5.push(`Terlama`);
          });
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div></div></div></div> `);
      if (filteredRecords.length === 0) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50"><svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-slate-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg> <h3 class="text-lg font-medium text-slate-900">Tidak Ada Data</h3> <p class="text-slate-500 max-w-sm mt-1">Tidak ditemukan laporan yang sesuai dengan pencarian Anda.</p></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"><!--[-->`);
        const each_array = ensure_array_like(filteredRecords);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let record = each_array[$$index];
          $$renderer3.push(`<div class="group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col"><div class="p-6 flex-1 space-y-4"><div class="flex justify-between items-start"><span${attr_class(clsx(cn("px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide border", record.reportStatus === "Completed" ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-amber-50 text-amber-700 border-amber-100")))}>${escape_html(record.reportStatus === "Completed" ? "Selesai" : "Pending")}</span> <span class="text-xs font-mono text-slate-400">${escape_html(record.spd)}</span></div> <div><h3 class="font-bold text-lg text-slate-800 line-clamp-2 group-hover:text-blue-600 transition-colors">${escape_html(record.purpose)}</h3> <p class="text-sm text-slate-500 mt-1 flex items-center gap-1"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg> ${escape_html(record.location)}, ${escape_html(record.province)}</p></div> <div class="flex items-center gap-3 text-xs text-slate-500 pt-2 border-t border-slate-50"><div class="flex items-center gap-1"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg> ${escape_html(record.startDate)}</div> <span>—</span> <div>${escape_html(record.endDate)}</div></div></div> <div class="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between"><div class="flex -space-x-2 overflow-hidden"><div class="h-6 w-6 rounded-full ring-2 ring-white bg-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-500 leading-none">${escape_html(getInitials(record.employee.name))}</div></div> <div class="flex gap-2">`);
          if (record.reportStatus === "Completed") {
            $$renderer3.push("<!--[-->");
            Button($$renderer3, {
              variant: "ghost",
              size: "sm",
              class: "h-8 w-8 p-0 rounded-full hover:bg-slate-200 text-slate-500",
              title: "Cetak Laporan",
              children: ($$renderer4) => {
                $$renderer4.push(`<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>`);
              },
              $$slots: { default: true }
            });
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]--> <a${attr("href", `/dashboard/laporan/${encodeURIComponent(record.spd)}`)}>`);
          Button($$renderer3, {
            size: "sm",
            class: cn("h-8 text-xs font-medium shadow-sm transition-all", record.reportStatus === "Completed" ? "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 hover:text-blue-600" : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20"),
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->${escape_html(record.reportStatus === "Completed" ? "Edit Laporan" : "Buat Laporan")}`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----></a></div></div></div>`);
        }
        $$renderer3.push(`<!--]--></div>`);
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
