import { s as store_get, u as unsubscribe_stores, e as escape_html, d as ensure_array_like, h as attr } from "../../../../../chunks/index2.js";
import { p as page } from "../../../../../chunks/stores.js";
import { r as recordsStore } from "../../../../../chunks/records.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../../../chunks/root.js";
import "../../../../../chunks/state.svelte.js";
import { B as Button } from "../../../../../chunks/Button.js";
import { L as Label } from "../../../../../chunks/Label.js";
import { T as Textarea } from "../../../../../chunks/Textarea.js";
import "clsx";
import "pdfjs-dist";
import "docx-preview";
import { D as Dialog } from "../../../../../chunks/Dialog.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let record;
    let spd = store_get($$store_subs ??= {}, "$page", page).params.spd;
    let reportText = "";
    let uploadedFiles = [];
    let isPreviewOpen = false;
    record = store_get($$store_subs ??= {}, "$recordsStore", recordsStore).find((r) => r.spd === decodeURIComponent(spd));
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="max-w-4xl mx-auto pb-20 space-y-8"><div class="flex items-center justify-between"><div><h2 class="text-3xl font-bold tracking-tight text-slate-900">Form Laporan Kegiatan</h2> <p class="text-slate-500">Isi detail laporan dan unggah dokumentasi kegiatan.</p></div> `);
      Button($$renderer3, {
        variant: "outline",
        class: "hidden sm:flex border-slate-200 text-slate-600 hover:text-slate-900",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Kembali`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div> `);
      if (!record) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="text-red-500 p-4 border border-red-200 rounded bg-red-50">Data perjalanan dinas tidak ditemukan.</div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div class="bg-slate-50/50 border-b border-slate-100 p-6 grid grid-cols-1 md:grid-cols-2 gap-6 text-sm"><div><span class="block text-xs font-semibold uppercase text-slate-400 tracking-wider mb-1">Nomor SPD</span> <span class="font-mono text-slate-700 font-medium bg-white px-2 py-1 rounded border border-slate-200 inline-block">${escape_html(record.spd)}</span></div> <div><span class="block text-xs font-semibold uppercase text-slate-400 tracking-wider mb-1">Pegawai Pelaksana</span> <span class="font-medium text-slate-800">${escape_html(record.employee.name)}</span> <span class="text-slate-500 block text-xs">${escape_html(record.employee.rank)}</span></div> <div><span class="block text-xs font-semibold uppercase text-slate-400 tracking-wider mb-1">Lokasi &amp; Tujuan</span> <span class="font-medium text-slate-800">${escape_html(record.location)}, ${escape_html(record.province)}</span></div> <div><span class="block text-xs font-semibold uppercase text-slate-400 tracking-wider mb-1">Periode Perjalanan</span> <span class="font-medium text-slate-800">${escape_html(record.startDate)} — ${escape_html(record.endDate)}</span></div></div> <div class="p-6 md:p-8 space-y-8"><div class="space-y-3"><div class="flex justify-between items-center">`);
        Label($$renderer3, {
          class: "text-base font-semibold text-slate-800",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Isi Laporan Kegiatan`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <span class="text-xs text-slate-400 font-medium px-2 py-1 bg-slate-50 rounded-full border border-slate-100">${escape_html(reportText.trim().split(/\s+/).filter((w) => w.length > 0).length)} / 200 Kata</span></div> `);
        Textarea($$renderer3, {
          rows: "12",
          class: "resize-y min-h-[200px] text-base leading-relaxed p-4 border-slate-200 focus:border-blue-300 focus:ring-blue-100 placeholder:text-slate-300",
          placeholder: "Deskripsikan hasil kegiatan, kendala yang dihadapi, dan tindak lanjut yang diperlukan...",
          get value() {
            return reportText;
          },
          set value($$value) {
            reportText = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----> <p class="text-xs text-slate-400 italic">Maksimal 200 kata. Gunakan bahasa yang baku dan jelas.</p></div> <div class="space-y-4 pt-6 border-t border-slate-100"><div class="flex justify-between items-center">`);
        Label($$renderer3, {
          class: "text-base font-semibold text-slate-800",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Dokumentasi Kegiatan`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <span class="text-xs text-slate-400">Max 6 File (JPG/PDF), Max 10MB</span></div> <label class="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 border-dashed rounded-lg cursor-pointer bg-slate-50 hover:bg-slate-100 hover:border-blue-300 transition-all group"><div class="flex flex-col items-center justify-center pt-5 pb-6"><svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 mb-3 text-slate-400 group-hover:text-blue-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg> <p class="mb-1 text-sm text-slate-500"><span class="font-semibold text-blue-600">Klik untuk unggah</span> atau seret file ke sini</p> <p class="text-xs text-slate-400">PDF, PNG, JPG (Maks. 10MB)</p></div> <input type="file" multiple="" accept="image/*,application/pdf" class="hidden"/></label> `);
        if (uploadedFiles.length > 0) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-6"><!--[-->`);
          const each_array = ensure_array_like(uploadedFiles);
          for (let i = 0, $$length = each_array.length; i < $$length; i++) {
            let file = each_array[i];
            $$renderer3.push(`<div class="group relative aspect-square bg-slate-100 rounded-lg overflow-hidden border border-slate-200 shadow-sm cursor-pointer">`);
            if (file.type.startsWith("image/")) {
              $$renderer3.push("<!--[-->");
              $$renderer3.push(`<img${attr("src", file.data)} alt="Preview" class="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"/>`);
            } else if (file.type === "application/pdf") {
              $$renderer3.push("<!--[1-->");
              $$renderer3.push(`<div class="flex flex-col items-center justify-center h-full text-red-500 bg-red-50 p-4 text-center group-hover:bg-red-100 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg> <span class="text-[10px] font-bold uppercase tracking-wider text-red-700">PDF Document</span> <span class="text-[9px] truncate w-full mt-1 text-red-600/70">${escape_html(file.name)}</span></div>`);
            } else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
              $$renderer3.push("<!--[2-->");
              $$renderer3.push(`<div class="flex flex-col items-center justify-center h-full text-blue-600 bg-blue-50 p-4 text-center group-hover:bg-blue-100 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg> <span class="text-[10px] font-bold uppercase tracking-wider text-blue-700">Word Document</span> <span class="text-[9px] truncate w-full mt-1 text-blue-600/70">${escape_html(file.name)}</span></div>`);
            } else {
              $$renderer3.push("<!--[!-->");
              $$renderer3.push(`<div class="flex flex-col items-center justify-center h-full text-slate-400 p-4 text-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg> <span class="text-[10px] truncate w-full">${escape_html(file.name)}</span></div>`);
            }
            $$renderer3.push(`<!--]--> <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-10"><div class="flex gap-2"><button class="bg-white/20 backdrop-blur-md text-white p-2 rounded-full hover:bg-white/40 transform hover:scale-110 transition-all shadow-lg" title="Lihat"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg></button> <button class="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transform hover:scale-110 transition-all shadow-lg" title="Hapus file"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button></div></div> <div class="absolute bottom-2 right-2 bg-black/60 backdrop-blur-[2px] text-white text-[9px] px-1.5 py-0.5 rounded pointer-events-none z-0">${escape_html(new Date(file.timestamp).toLocaleDateString())}</div></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--></div></div> <div class="bg-slate-50 border-t border-slate-100 p-6 flex justify-end">`);
        Button($$renderer3, {
          size: "lg",
          class: "bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20 px-8",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Simpan Laporan Akhir`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div></div>`);
      }
      $$renderer3.push(`<!--]--> `);
      Dialog($$renderer3, {
        open: isPreviewOpen,
        class: "max-w-5xl h-[85vh] p-0 overflow-hidden",
        children: ($$renderer4) => {
          $$renderer4.push(`<div class="h-full flex flex-col"><div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex-none"><div class="flex flex-col"><h3 class="text-lg font-bold text-slate-800 tracking-tight">Pratinjau Dokumen</h3> `);
          {
            $$renderer4.push("<!--[!-->");
          }
          $$renderer4.push(`<!--]--></div> <button class="p-2 hover:bg-slate-200 rounded-full text-slate-400 hover:text-slate-600 transition-colors"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button></div> <div class="flex-1 overflow-hidden bg-slate-100 relative p-0">`);
          {
            $$renderer4.push("<!--[!-->");
          }
          $$renderer4.push(`<!--]--></div></div>`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
