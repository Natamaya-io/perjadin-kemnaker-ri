import { e as escape_html } from "../../../chunks/index2.js";
import "clsx";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/root.js";
import "../../../chunks/state.svelte.js";
import { B as Button } from "../../../chunks/Button.js";
import { I as Input } from "../../../chunks/Input.js";
import { L as Label } from "../../../chunks/Label.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let email = "";
    let password = "";
    let isLoading = false;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<div class="relative min-h-[100dvh] w-full flex flex-col items-center justify-center p-4 sm:p-6 overflow-x-hidden svelte-1x05zx6"><div class="fixed inset-0 z-0 bg-slate-900 pointer-events-none svelte-1x05zx6"><div class="absolute inset-0 bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#1e293b] svelte-1x05zx6"></div> <div class="absolute top-[-10%] left-[-10%] w-[60vw] h-[60vw] bg-blue-600/20 rounded-full blur-[120px] animate-pulse svelte-1x05zx6"></div> <div class="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] bg-indigo-600/20 rounded-full blur-[120px] animate-pulse svelte-1x05zx6" style="animation-delay: 2s;"></div> <div class="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))] opacity-10 svelte-1x05zx6"></div></div> <a href="/" class="fixed top-6 left-6 z-20 p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all backdrop-blur-md border border-white/5 svelte-1x05zx6" title="Kembali ke Beranda"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 svelte-1x05zx6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" class="svelte-1x05zx6"></path></svg></a> <div class="relative z-10 w-full max-w-[400px] flex flex-col my-auto svelte-1x05zx6"><div class="bg-white/95 backdrop-blur-2xl border border-white/20 rounded-3xl shadow-2xl shadow-black/20 overflow-hidden ring-1 ring-white/40 svelte-1x05zx6"><div class="relative px-8 pt-10 pb-6 text-center bg-gradient-to-b from-white via-white to-slate-50/80 border-b border-slate-100/80 svelte-1x05zx6"><img src="/kemnaker-ri.webp" alt="Logo Kemnaker RI" class="mx-auto h-20 w-auto object-contain mb-5 svelte-1x05zx6"/> <div class="space-y-1 svelte-1x05zx6"><h1 class="text-2xl font-serif font-bold tracking-tight text-slate-900 svelte-1x05zx6">Perjadin Protokol</h1> <p class="text-xs font-medium text-slate-500 uppercase tracking-widest svelte-1x05zx6">Kementerian Ketenagakerjaan RI</p></div></div> <div class="p-6 sm:p-8 space-y-6 bg-white svelte-1x05zx6"><div class="bg-blue-50/60 border border-blue-100/60 rounded-xl p-3.5 flex flex-col gap-1.5 svelte-1x05zx6"><div class="flex items-center gap-2 text-xs font-bold text-blue-800 svelte-1x05zx6"><svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 svelte-1x05zx6" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" class="svelte-1x05zx6"></path></svg> Akun Demo (Password: 123456)</div> <div class="text-[10px] text-blue-700/80 font-mono pl-5 grid grid-cols-1 gap-0.5 svelte-1x05zx6"><div class="flex justify-between svelte-1x05zx6"><span class="svelte-1x05zx6">Staf:</span> <span class="select-all cursor-pointer hover:text-blue-900 svelte-1x05zx6">user@kemnaker.go.id</span></div> <div class="flex justify-between svelte-1x05zx6"><span class="svelte-1x05zx6">Super Admin:</span> <span class="select-all cursor-pointer hover:text-blue-900 svelte-1x05zx6">admin@kemnaker.go.id</span></div> <div class="flex justify-between svelte-1x05zx6"><span class="svelte-1x05zx6">Keuangan:</span> <span class="select-all cursor-pointer hover:text-blue-900 svelte-1x05zx6">keuangan@kemnaker.go.id</span></div> <div class="flex justify-between svelte-1x05zx6"><span class="svelte-1x05zx6">PPK:</span> <span class="select-all cursor-pointer hover:text-blue-900 svelte-1x05zx6">ppk@kemnaker.go.id</span></div></div></div> `);
      {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> <form class="space-y-5 svelte-1x05zx6"><div class="space-y-1.5 group svelte-1x05zx6">`);
      Label($$renderer3, {
        class: "text-xs font-bold text-slate-500 uppercase tracking-wider ml-1 group-focus-within:text-blue-600 transition-colors",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Email Kedinasan`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> <div class="relative svelte-1x05zx6"><div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors svelte-1x05zx6"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 svelte-1x05zx6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" class="svelte-1x05zx6"></path></svg></div> `);
      Input($$renderer3, {
        type: "email",
        placeholder: "nama@kemnaker.go.id",
        class: "pl-11 h-12 text-sm bg-slate-50 border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all rounded-xl shadow-sm placeholder:text-slate-300",
        get value() {
          return email;
        },
        set value($$value) {
          email = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----></div></div> <div class="space-y-1.5 group svelte-1x05zx6">`);
      Label($$renderer3, {
        class: "text-xs font-bold text-slate-500 uppercase tracking-wider ml-1 group-focus-within:text-blue-600 transition-colors",
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Password`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----> <div class="relative svelte-1x05zx6"><div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors svelte-1x05zx6"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 svelte-1x05zx6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" class="svelte-1x05zx6"></path></svg></div> `);
      Input($$renderer3, {
        type: "password",
        placeholder: "••••••••",
        class: "pl-11 pr-11 h-12 text-sm bg-slate-50 border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all rounded-xl shadow-sm placeholder:text-slate-300",
        get value() {
          return password;
        },
        set value($$value) {
          password = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> <button type="button" class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none transition-colors svelte-1x05zx6" tabindex="-1">`);
      {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 svelte-1x05zx6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" class="svelte-1x05zx6"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" class="svelte-1x05zx6"></path></svg>`);
      }
      $$renderer3.push(`<!--]--></button></div></div> `);
      Button($$renderer3, {
        type: "submit",
        class: "w-full h-12 text-sm font-bold text-white shadow-lg shadow-blue-500/30 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all transform active:scale-[0.98] rounded-xl",
        disabled: isLoading,
        children: ($$renderer4) => {
          {
            $$renderer4.push("<!--[!-->");
            $$renderer4.push(`Masuk Dashboard`);
          }
          $$renderer4.push(`<!--]-->`);
        },
        $$slots: { default: true }
      });
      $$renderer3.push(`<!----></form></div> <div class="px-8 py-4 bg-slate-50 border-t border-slate-100 flex justify-center svelte-1x05zx6"><p class="text-[10px] text-slate-400 font-medium tracking-wide svelte-1x05zx6">Sistem Informasi Terintegrasi © ${escape_html((/* @__PURE__ */ new Date()).getFullYear())}</p></div></div> <div class="mt-8 text-center svelte-1x05zx6"><a href="/" class="text-xs text-white/40 hover:text-white/80 transition-colors font-medium svelte-1x05zx6">Butuh bantuan teknis?</a></div></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
