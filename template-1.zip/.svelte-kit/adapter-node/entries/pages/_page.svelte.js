import { s as store_get, e as escape_html, u as unsubscribe_stores } from "../../chunks/index2.js";
import "clsx";
import { u as userStore } from "../../chunks/auth.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    $$renderer2.push(`<div class="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden bg-[#0f172a] text-white selection:bg-blue-500/30"><div class="absolute inset-0 z-0"><div class="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1e293b] via-[#0f172a] to-[#020617] opacity-80"></div> <div class="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] mix-blend-overlay"></div> <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-900/20 rounded-full blur-[120px] animate-pulse" style="animation-duration: 4s;"></div></div> <nav class="absolute top-0 w-full z-20 px-8 py-8 flex justify-between items-center max-w-7xl mx-auto"><div class="flex items-center gap-4 opacity-0 animate-[fadeIn_1s_ease-out_forwards]"><img src="/kemnaker-ri.webp" alt="Logo Kemnaker" class="h-12 w-auto drop-shadow-lg"/></div> <div class="opacity-0 animate-[fadeIn_1s_ease-out_0.2s_forwards]">`);
    if (!store_get($$store_subs ??= {}, "$userStore", userStore).loggedIn) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<a href="/login" class="text-sm font-medium tracking-wide text-slate-300 hover:text-white transition-colors duration-300">Masuk Akun</a>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<a href="/dashboard/pengajuan/new" class="text-sm font-medium tracking-wide text-slate-300 hover:text-white transition-colors duration-300">Dashboard</a>`);
    }
    $$renderer2.push(`<!--]--></div></nav> <main class="relative z-10 container max-w-4xl mx-auto px-4 text-center">`);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></main> <footer class="absolute bottom-0 w-full py-6 text-center z-10 opacity-0 animate-[fadeIn_1s_ease-out_1s_forwards]"><p class="text-[10px] uppercase tracking-[0.2em] text-slate-600">© ${escape_html((/* @__PURE__ */ new Date()).getFullYear())} Biro Umum Kemnaker RI</p></footer></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
