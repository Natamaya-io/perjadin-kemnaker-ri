import { s as store_get, a as attr_class, b as stringify, e as escape_html, c as slot, u as unsubscribe_stores } from "../../chunks/index2.js";
import { u as userStore } from "../../chunks/auth.js";
import { p as page } from "../../chunks/stores.js";
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let activeRoute;
    activeRoute = store_get($$store_subs ??= {}, "$page", page).url.pathname;
    $$renderer2.push(`<div${attr_class(`h-[100dvh] w-screen flex flex-col font-sans antialiased text-slate-900 overflow-hidden ${stringify(activeRoute.startsWith("/login") ? "bg-slate-900" : "bg-slate-50")}`)}>`);
    if (store_get($$store_subs ??= {}, "$userStore", userStore).loggedIn) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<header class="hidden md:block sticky top-0 z-50 w-full border-b border-slate-200 bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 shadow-sm transition-all flex-none"><div class="container flex h-16 items-center max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="mr-8 flex items-center"><a class="flex items-center space-x-3 group" href="/"><img src="/kemnaker-ri.webp" alt="Logo" class="h-10 w-auto object-contain group-hover:scale-105 transition-transform"/> <div class="hidden sm:flex flex-col leading-none"><span class="font-serif font-bold text-lg text-slate-900 tracking-tight">Perjadin</span> <span class="font-sans text-xs italic text-slate-500 tracking-widest uppercase">Protokol</span></div></a></div> <nav class="flex items-center space-x-1 text-sm font-medium flex-1"><a${attr_class(`px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 ${stringify(activeRoute.includes("/dashboard/pengajuan") ? "text-primary bg-blue-50/50 font-semibold" : "text-slate-600")}`)} href="/dashboard/pengajuan/new">Pengajuan</a> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin" || store_get($$store_subs ??= {}, "$userStore", userStore).role === "keuangan") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<a${attr_class(`px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 ${stringify(activeRoute.includes("/dashboard/admin/perdin") ? "text-primary bg-blue-50/50 font-semibold" : "text-slate-600")}`)} href="/dashboard/admin/perdin">Admin Keuangan</a>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<a${attr_class(`px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 ${stringify(activeRoute.includes("/dashboard/admin/petugas") ? "text-primary bg-blue-50/50 font-semibold" : "text-slate-600")}`)} href="/dashboard/admin/petugas">Petugas</a> <a${attr_class(`px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 ${stringify(activeRoute.includes("/dashboard/admin/users") ? "text-primary bg-blue-50/50 font-semibold" : "text-slate-600")}`)} href="/dashboard/admin/users">User</a>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <a${attr_class(`px-4 py-2 rounded-lg transition-all hover:bg-slate-100/80 ${stringify(activeRoute.includes("/dashboard/laporan") ? "text-primary bg-blue-50/50 font-semibold" : "text-slate-600")}`)} href="/dashboard/laporan">Laporan</a></nav> <div class="flex items-center space-x-4"><div class="flex items-center space-x-3 text-sm bg-slate-100/50 px-3 py-1.5 rounded-full border border-slate-200/60"><span class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Role</span> <span class="text-xs font-bold text-slate-800 uppercase">${escape_html(store_get($$store_subs ??= {}, "$userStore", userStore).role)}</span></div> <button class="text-slate-400 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-red-50" title="Logout"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg></button></div></div></header> <header class="md:hidden sticky top-0 z-50 w-full bg-white/90 backdrop-blur border-b border-slate-200 px-4 py-3 flex justify-between items-center shadow-sm flex-none"><div class="flex items-center space-x-2"><img src="/kemnaker-ri.webp" alt="Logo" class="h-8 w-auto object-contain"/> <div class="flex flex-col leading-none"><span class="font-serif font-bold text-base text-slate-900 tracking-tight">Perjadin</span> <span class="font-sans text-[10px] italic text-slate-500 tracking-widest uppercase">Protokol</span></div></div> <button class="text-slate-500"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg></button></header>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <main class="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar w-full relative"><div${attr_class(`${stringify(store_get($$store_subs ??= {}, "$userStore", userStore).loggedIn ? "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 md:pb-8" : "")} min-h-full`)}><!---->`);
    {
      $$renderer2.push(`<div class="min-h-full"><!--[-->`);
      slot($$renderer2, $$props, "default", {});
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!----></div></main> `);
    if (store_get($$store_subs ??= {}, "$userStore", userStore).loggedIn) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<nav class="md:hidden sticky bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] flex-none"><div${attr_class(`grid ${stringify(store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin" ? "grid-cols-5" : store_get($$store_subs ??= {}, "$userStore", userStore).role === "keuangan" ? "grid-cols-3" : "grid-cols-2")} h-16`)}><a href="/dashboard/pengajuan/new"${attr_class(`flex flex-col items-center justify-center space-y-1 ${stringify(activeRoute.includes("/dashboard/pengajuan") ? "text-blue-600" : "text-slate-400 hover:text-slate-600")}`)}><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg> <span class="text-[10px] font-medium">Pengajuan</span></a> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin" || store_get($$store_subs ??= {}, "$userStore", userStore).role === "keuangan") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<a href="/dashboard/admin/perdin"${attr_class(`flex flex-col items-center justify-center space-y-1 ${stringify(activeRoute.includes("/dashboard/admin/perdin") ? "text-blue-600" : "text-slate-400 hover:text-slate-600")}`)}><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 3.666A5.002 5.002 0 0112 21a5.002 5.002 0 01-3-9.666V5.5A2.5 2.5 0 0012 3a2.5 2.5 0 002.5 2.5V7z"></path></svg> <span class="text-[10px] font-medium">Admin</span></a>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (store_get($$store_subs ??= {}, "$userStore", userStore).role === "super_admin") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<a href="/dashboard/admin/petugas"${attr_class(`flex flex-col items-center justify-center space-y-1 ${stringify(activeRoute.includes("/dashboard/admin/petugas") ? "text-blue-600" : "text-slate-400 hover:text-slate-600")}`)}><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg> <span class="text-[10px] font-medium">Petugas</span></a> <a href="/dashboard/admin/users"${attr_class(`flex flex-col items-center justify-center space-y-1 ${stringify(activeRoute.includes("/dashboard/admin/users") ? "text-blue-600" : "text-slate-400 hover:text-slate-600")}`)}><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> <span class="text-[10px] font-medium">User</span></a>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <a href="/dashboard/laporan"${attr_class(`flex flex-col items-center justify-center space-y-1 ${stringify(activeRoute.includes("/dashboard/laporan") ? "text-blue-600" : "text-slate-400 hover:text-slate-600")}`)}><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transition-transform active:scale-90" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg> <span class="text-[10px] font-medium">Laporan</span></a></div></nav>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _layout as default
};
