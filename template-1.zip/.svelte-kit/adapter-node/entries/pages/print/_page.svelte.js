import { s as store_get, m as head, e as escape_html, d as ensure_array_like, h as attr, u as unsubscribe_stores } from "../../../chunks/index2.js";
import { p as page } from "../../../chunks/stores.js";
import { r as recordsStore } from "../../../chunks/records.js";
import { B as Button } from "../../../chunks/Button.js";
function terbilang(nominal) {
  const bilangan = [
    "",
    "Satu",
    "Dua",
    "Tiga",
    "Empat",
    "Lima",
    "Enam",
    "Tujuh",
    "Delapan",
    "Sembilan",
    "Sepuluh",
    "Sebelas"
  ];
  let temp = "";
  if (nominal < 12) {
    temp = " " + bilangan[nominal];
  } else if (nominal < 20) {
    temp = terbilang(nominal - 10) + " Belas";
  } else if (nominal < 100) {
    temp = terbilang(Math.floor(nominal / 10)) + " Puluh" + terbilang(nominal % 10);
  } else if (nominal < 200) {
    temp = " Seratus" + terbilang(nominal - 100);
  } else if (nominal < 1e3) {
    temp = terbilang(Math.floor(nominal / 100)) + " Ratus" + terbilang(nominal % 100);
  } else if (nominal < 2e3) {
    temp = " Seribu" + terbilang(nominal - 1e3);
  } else if (nominal < 1e6) {
    temp = terbilang(Math.floor(nominal / 1e3)) + " Ribu" + terbilang(nominal % 1e3);
  } else if (nominal < 1e9) {
    temp = terbilang(Math.floor(nominal / 1e6)) + " Juta" + terbilang(nominal % 1e6);
  } else if (nominal < 1e12) {
    temp = terbilang(Math.floor(nominal / 1e9)) + " Milyar" + terbilang(nominal % 1e9);
  }
  return temp.trim();
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let record;
    let type = store_get($$store_subs ??= {}, "$page", page).url.searchParams.get("type");
    let spd = store_get($$store_subs ??= {}, "$page", page).url.searchParams.get("spd");
    record = store_get($$store_subs ??= {}, "$recordsStore", recordsStore).find((r) => r.spd === spd);
    head("10vhg08", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Cetak ${escape_html(type ? type.toUpperCase() : "Dokumen")} - ${escape_html(spd || "")}</title>`);
      });
    });
    $$renderer2.push(`<div class="min-h-screen bg-slate-100 p-8 font-serif text-black print:p-0 print:bg-white"><div class="max-w-[210mm] mx-auto mb-6 flex justify-between items-center print:hidden">`);
    Button($$renderer2, {
      variant: "outline",
      class: "bg-white border-slate-300 hover:bg-slate-50",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg> Kembali`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="flex gap-2">`);
    Button($$renderer2, {
      class: "bg-blue-600 hover:bg-blue-700 text-white shadow-sm",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg> Cetak / Simpan PDF`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div> <div class="max-w-[210mm] min-h-[297mm] mx-auto bg-white shadow-xl print:shadow-none p-[20mm] print:p-0 relative">`);
    if (!record) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex flex-col items-center justify-center h-96 text-slate-400"><svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> <p class="text-lg font-medium">Data dokumen tidak ditemukan.</p> <p class="text-sm">Pastikan nomor SPD benar atau kembali ke dashboard.</p></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="flex items-start justify-center gap-6 border-b-[3px] border-black pb-4 mb-8"><img src="/kemnaker-ri.webp" alt="Logo Kemnaker" class="h-24 w-auto object-contain"/> <div class="text-center flex-1 pt-1"><h2 class="text-xl font-bold uppercase tracking-wide leading-tight">Kementerian Ketenagakerjaan<br/>Republik Indonesia</h2> <h3 class="text-base font-bold uppercase mt-1">Biro Protokol dan Hubungan Masyarakat</h3> <p class="text-[11px] mt-1 leading-tight">Jalan Jenderal Gatot Subroto Kaveling 51, Jakarta Selatan 12950</p> <p class="text-[11px] leading-tight">Telepon: (021) 525 5733 • Faksimili: (021) 525 5733</p> <p class="text-[11px] leading-tight font-medium text-blue-900">Laman: www.kemnaker.go.id</p></div></div> `);
      if (type === "spd") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="space-y-6"><div class="grid grid-cols-2 text-sm"><div></div> <div class="space-y-1"><div class="flex"><span class="w-24">Lembar ke</span> <span>: 1</span></div> <div class="flex"><span class="w-24">Kode No</span> <span>: ....................</span></div> <div class="flex"><span class="w-24">Nomor</span> <span>: ${escape_html(record.spd)}</span></div></div></div> <div class="text-center space-y-1 mt-4"><h1 class="text-xl font-bold uppercase underline decoration-2 underline-offset-4">Surat Perjalanan Dinas (SPD)</h1></div> <div class="space-y-2 mt-8 text-sm leading-relaxed"><div class="flex"><span class="w-8 font-bold">1.</span> <span class="w-1/3">Pejabat Pembuat Komitmen</span> <span class="flex-1">: Kepala Biro Protokol dan Humas</span></div> <div class="flex"><span class="w-8 font-bold">2.</span> <span class="w-1/3">Nama Pegawai yang diperintah</span> <span class="flex-1 font-semibold uppercase">: ${escape_html(record.employee.name)}</span></div> <div class="flex"><span class="w-8 font-bold">3.</span> <div class="w-1/3 space-y-1"><p>a. Pangkat dan Golongan</p> <p>b. Jabatan/Instansi</p> <p>c. Tingkat Biaya Perjalanan Dinas</p></div> <div class="flex-1 space-y-1"><p>: ${escape_html(record.employee.rank)} (${escape_html(record.employee.golongan)})</p> <p>: Staf Protokol / Kementerian Ketenagakerjaan</p> <p>: C</p></div></div> <div class="flex"><span class="w-8 font-bold">4.</span> <span class="w-1/3">Maksud Perjalanan Dinas</span> <span class="flex-1 text-justify">: ${escape_html(record.purpose)}</span></div> <div class="flex"><span class="w-8 font-bold">5.</span> <span class="w-1/3">Alat Angkutan yang dipergunakan</span> <span class="flex-1">: ${escape_html(record.costs.transportMode)}</span></div> <div class="flex"><span class="w-8 font-bold">6.</span> <div class="w-1/3 space-y-1"><p>a. Tempat Berangkat</p> <p>b. Tempat Tujuan</p></div> <div class="flex-1 space-y-1"><p>: Jakarta</p> <p>: ${escape_html(record.location)}, ${escape_html(record.province)}</p></div></div> <div class="flex"><span class="w-8 font-bold">7.</span> <div class="w-1/3 space-y-1"><p>a. Lama Perjalanan Dinas</p> <p>b. Tanggal Berangkat</p> <p>c. Tanggal Harus Kembali</p></div> <div class="flex-1 space-y-1"><p>: ${escape_html(Math.ceil((new Date(record.endDate) - new Date(record.startDate)) / (1e3 * 60 * 60 * 24)) + 1)} (....................) hari</p> <p>: ${escape_html(new Date(record.startDate).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</p> <p>: ${escape_html(new Date(record.endDate).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</p></div></div> <div class="flex"><span class="w-8 font-bold">8.</span> <span class="w-1/3">Pembebanan Anggaran</span> <span class="flex-1">: DIPA Biro Protokol dan Humas TA ${escape_html((/* @__PURE__ */ new Date()).getFullYear())}</span></div> <div class="flex"><span class="w-8 font-bold">9.</span> <span class="w-1/3">Keterangan Lain-lain</span> <span class="flex-1">: -</span></div></div> <div class="mt-16 grid grid-cols-2 gap-8"><div></div> <div class="text-center space-y-24"><div><p>Dikeluarkan di: Jakarta</p> <p>Pada tanggal: ${escape_html((/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</p> <p class="font-bold mt-4">Pejabat Pembuat Komitmen</p></div> <div><p class="font-bold underline uppercase">Nama Pejabat</p> <p>NIP. 19700101 199002 1 001</p></div></div></div></div>`);
      } else if (type === "rincian") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="space-y-6"><div class="text-center space-y-1 mb-8"><h1 class="text-xl font-bold uppercase underline decoration-2 underline-offset-4">Rincian Biaya Perjalanan Dinas</h1> <p class="text-sm font-medium">Lampiran SPD Nomor: ${escape_html(record.spd)}</p></div> <div class="space-y-1 text-sm mb-6"><div class="flex"><span class="w-48">Tanggal</span> <span>: ${escape_html(new Date(record.startDate).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</span></div></div> <table class="w-full border-collapse border border-black text-sm"><thead><tr class="bg-slate-100"><th class="border border-black p-2 text-center w-12">No</th><th class="border border-black p-2 text-left">Perincian Biaya</th><th class="border border-black p-2 text-right w-40">Jumlah</th><th class="border border-black p-2 text-left w-1/3">Keterangan</th></tr></thead><tbody><tr><td class="border border-black p-2 text-center align-top">1</td><td class="border border-black p-2 align-top"><div class="font-bold mb-1">Biaya Transportasi</div> <div class="pl-4 text-xs space-y-1"><div class="flex justify-between"><span>Tiket Berangkat</span> <span>${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.ticketGo))}</span></div> <div class="flex justify-between"><span>Tiket Pulang</span> <span>${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.ticketBack))}</span></div></div></td><td class="border border-black p-2 text-right align-top font-medium">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(Number(record.costs.ticketGo) + Number(record.costs.ticketBack)))}</td><td class="border border-black p-2 text-xs align-top">Sesuai bukti tiket terlampir.</td></tr><tr><td class="border border-black p-2 text-center align-top">2</td><td class="border border-black p-2 align-top"><div class="font-bold mb-1">Uang Harian</div> <div class="pl-4 text-xs">${escape_html(record.costs.dailyAllowanceDays)} hari x ${escape_html(new Intl.NumberFormat("id-ID").format(record.costs.dailyAllowanceRate))}</div></td><td class="border border-black p-2 text-right align-top font-medium">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.dailyAllowanceDays * record.costs.dailyAllowanceRate))}</td><td class="border border-black p-2 text-xs align-top">Uang saku, uang makan, dan transport lokal.</td></tr><tr><td class="border border-black p-2 text-center align-top">3</td><td class="border border-black p-2 align-top"><div class="font-bold mb-1">Biaya Penginapan</div> <div class="pl-4 text-xs">${escape_html(record.costs.hotelDays)} malam x ${escape_html(new Intl.NumberFormat("id-ID").format(record.costs.hotelRate))}</div></td><td class="border border-black p-2 text-right align-top font-medium">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.hotelDays * record.costs.hotelRate))}</td><td class="border border-black p-2 text-xs align-top">Sesuai bill hotel terlampir (30%).</td></tr><tr><td class="border border-black p-2 text-center align-top">4</td><td class="border border-black p-2 align-top"><div class="font-bold mb-1">Lain-lain</div> <div class="pl-4 text-xs space-y-1">`);
        if (record.costs.localTransport > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex justify-between"><span>Transport Lokal</span> <span>${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.localTransport))}</span></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (record.costs.regionalTransport > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex justify-between"><span>Transport Daerah</span> <span>${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.costs.regionalTransport))}</span></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div></td><td class="border border-black p-2 text-right align-top font-medium">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(Number(record.costs.localTransport) + Number(record.costs.regionalTransport)))}</td><td class="border border-black p-2 text-xs align-top">Dukungan transport kegiatan.</td></tr><tr class="bg-slate-50"><td class="border border-black p-2 font-bold text-center" colspan="2">Jumlah Total</td><td class="border border-black p-2 text-right font-bold text-base">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.totalCost))}</td><td class="border border-black p-2 bg-slate-50"></td></tr><tr><td class="border border-black p-3" colspan="4"><span class="font-bold">Terbilang:</span> <span class="italic capitalize bg-slate-100 px-2 py-0.5 rounded">${escape_html(terbilang(record.totalCost))} Rupiah</span></td></tr></tbody></table> <div class="mt-16 grid grid-cols-2 gap-12 text-center text-sm"><div class="space-y-20"><div><p>Telah dibayar sejumlah</p> <p class="font-bold">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.totalCost))}</p></div> <div><p class="font-bold">Bendahara Pengeluaran</p> <br/><br/><br/> <p class="font-bold underline">(......................................)</p> <p>NIP. ..................................</p></div></div> <div class="space-y-20"><div><p>Jakarta, ${escape_html((/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</p> <p>Telah menerima jumlah uang sebesar</p> <p class="font-bold">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.totalCost))}</p></div> <div><p class="font-bold">Yang Menerima</p> <br/><br/><br/> <p class="font-bold underline">${escape_html(record.employee.name)}</p> <p>NIP. ${escape_html(record.employee.nip)}</p></div></div></div> <div class="border-t-2 border-black border-dashed mt-8 pt-4 text-center"><p class="font-bold mb-8">PERHITUNGAN RAMPUNG</p> <div class="grid grid-cols-2 gap-12 text-sm"><div class="space-y-20"><div><p>Ditetapkan sejumlah</p> <p class="font-bold">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.totalCost))}</p></div> <div><p class="font-bold">Pejabat Pembuat Komitmen</p> <br/><br/><br/> <p class="font-bold underline">(......................................)</p> <p>NIP. ..................................</p></div></div> <div class="space-y-20"><div><p>Yang telah dibayar semula</p> <p class="font-bold">Rp 0</p></div> <div><p>Sisa Kurang / Lebih</p> <p class="font-bold">${escape_html(new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(record.totalCost))}</p></div></div></div></div></div>`);
      } else if (type === "laporan") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`<div class="space-y-6 font-sans"><div class="text-center space-y-1 mb-8 border-b pb-4"><h1 class="text-xl font-bold uppercase">Laporan Pelaksanaan Perjalanan Dinas</h1> <p class="text-sm font-normal text-slate-500 mt-1">Berdasarkan SPD Nomor: ${escape_html(record.spd)}</p></div> <div class="grid grid-cols-2 gap-4 mb-6 text-sm bg-slate-50 p-4 rounded-lg border border-slate-200 print:bg-white print:border-none print:p-0"><div><span class="font-bold block text-slate-700">Nama Pelaksana:</span> <span class="text-lg">${escape_html(record.employee.name)}</span> <span class="block text-xs text-slate-500">NIP. ${escape_html(record.employee.nip)}</span> <span class="block text-xs text-slate-500 mt-1">${escape_html(record.employee.rank)}</span></div> <div class="text-right"><span class="font-bold block text-slate-700">Waktu &amp; Tempat:</span> <span>${escape_html(new Date(record.startDate).toLocaleDateString("id-ID"))} s.d ${escape_html(new Date(record.endDate).toLocaleDateString("id-ID"))}</span> <span class="block text-sm font-semibold text-blue-800 mt-1">${escape_html(record.location)}, ${escape_html(record.province)}</span></div></div> <div class="mb-8"><h3 class="font-bold border-b border-slate-300 mb-2 pb-1 text-lg">I. Hasil Kegiatan</h3> <div class="text-justify whitespace-pre-wrap leading-relaxed text-sm">${escape_html(record.reportData?.text || "Belum ada laporan yang disubmit oleh pegawai.")}</div></div> <div class="mb-8 page-break-inside-avoid"><h3 class="font-bold border-b border-slate-300 mb-4 pb-1 text-lg">II. Dokumentasi</h3> `);
        if (record.reportData?.files && record.reportData.files.length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="grid grid-cols-2 gap-4"><!--[-->`);
          const each_array = ensure_array_like(record.reportData.files);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let file = each_array[$$index];
            if (file.type.startsWith("image/")) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<div class="border p-2 rounded-lg break-inside-avoid"><img${attr("src", file.data)}${attr("alt", file.name)} class="w-full h-48 object-cover mb-2 rounded bg-slate-100"/> <p class="text-[10px] text-center text-slate-500">${escape_html(file.name)} - ${escape_html(new Date(file.timestamp).toLocaleDateString())}</p></div>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]-->`);
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="p-8 text-center bg-slate-50 rounded-lg border border-dashed border-slate-300 print:hidden"><p class="text-sm text-slate-500 italic">Tidak ada dokumentasi terlampir.</p></div> <p class="hidden print:block text-sm text-slate-500 italic">Tidak ada dokumentasi terlampir.</p>`);
        }
        $$renderer2.push(`<!--]--></div> <div class="mt-16 flex justify-end text-center page-break-inside-avoid"><div><p>Jakarta, ${escape_html((/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }))}</p> <p class="font-bold">Pelaksana Perjalanan Dinas</p> <br/><br/><br/> <p class="font-bold underline uppercase">${escape_html(record.employee.name)}</p> <p>NIP. ${escape_html(record.employee.nip)}</p></div></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
