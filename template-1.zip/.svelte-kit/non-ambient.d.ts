
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/dashboard" | "/dashboard/admin" | "/dashboard/admin/perdin" | "/dashboard/admin/petugas" | "/dashboard/admin/users" | "/dashboard/laporan" | "/dashboard/laporan/[spd]" | "/dashboard/pengajuan" | "/dashboard/pengajuan/new" | "/login" | "/print";
		RouteParams(): {
			"/dashboard/laporan/[spd]": { spd: string }
		};
		LayoutParams(): {
			"/": { spd?: string };
			"/dashboard": { spd?: string };
			"/dashboard/admin": Record<string, never>;
			"/dashboard/admin/perdin": Record<string, never>;
			"/dashboard/admin/petugas": Record<string, never>;
			"/dashboard/admin/users": Record<string, never>;
			"/dashboard/laporan": { spd?: string };
			"/dashboard/laporan/[spd]": { spd: string };
			"/dashboard/pengajuan": Record<string, never>;
			"/dashboard/pengajuan/new": Record<string, never>;
			"/login": Record<string, never>;
			"/print": Record<string, never>
		};
		Pathname(): "/" | "/dashboard" | "/dashboard/admin/perdin" | "/dashboard/admin/petugas" | "/dashboard/admin/users" | "/dashboard/laporan" | `/dashboard/laporan/${string}` & {} | "/dashboard/pengajuan/new" | "/login" | "/print";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/grid.svg" | "/kemnaker-ri.webp" | "/robots.txt" | string & {};
	}
}